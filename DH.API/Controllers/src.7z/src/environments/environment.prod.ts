export const environment = {
  production: true,
  baseUrl: 'http://192.168.1.235:8088/'
};

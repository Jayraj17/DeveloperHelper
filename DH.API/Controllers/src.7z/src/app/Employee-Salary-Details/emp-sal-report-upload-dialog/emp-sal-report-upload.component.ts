import { Component, OnInit } from '@angular/core';
import { EmployeeSalaryDetailsService } from '../service/employee-salary-details.service';
import { MatDialogRef } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { SharedServiceService } from 'src/app/services/shared-service.service';

@Component({
  selector: 'app-emp-sal-report-upload-dialog',
  templateUrl: './emp-sal-report-upload.component.html',
  styleUrls: ['./emp-sal-report-upload.component.css']
})
export class EmpSalReportUploadComponent implements OnInit {

  constructor(private sharedService: SharedServiceService, private dialogRef: MatDialogRef<EmpSalReportUploadComponent>,
              private toastr: ToastrService) { }

  public selectedFile: File = null;

  ngOnInit() {
  }

  public onFileSelected(event): void {
    if (event.target.files.length > 0) {
      this.selectedFile = event.target.files[0];
    }
  }

  public onUpload(): void {
    if (this.selectedFile) {
      const fd = new FormData();
      fd.append('file', this.selectedFile);
      this.sharedService.uploadFile(fd, 'Reports/PaidDaysExcel', 1).subscribe(
        (res) => {
          this.toastr.success('File uploaded sucessfully');
          this.dialogRef.close();
        },
        (err) => { this.toastr.error('Error while uploading file'); }
      );
    }
  }


}

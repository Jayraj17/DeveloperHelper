export class SalayStructureCode {

    public StructureId?: number;
    public StructureCode: string;
    public Basic: number;
    public HRA: number;
    public Medical: number;
    public Conveyance: number;
    public WebResearch: number;
    public PfEmployee: number;
    public PfEmployer: number;
    public EsicEmployee: number;
    public EsicEmployer: number;
    public ProfessionalTax: number;
    public OtherEarning: number;
    public OtherDeduction: number;
    public Incentive: number;
    public TDS: number;
}

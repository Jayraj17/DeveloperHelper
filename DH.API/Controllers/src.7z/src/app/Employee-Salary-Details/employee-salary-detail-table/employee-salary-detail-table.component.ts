import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { EmployeeSalaryDetailsService } from '../service/employee-salary-details.service';
import { EmployeeSalary } from '../models/employee-salary.model';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material';
import { MatSort } from '@angular/material/sort';
import { EmployeeSalaryDetailsDialogComponent } from '../employee-salary-details-dialog/employee-salary-details-dialog.component';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { EmpSalReportUploadComponent } from '../emp-sal-report-upload-dialog/emp-sal-report-upload.component';
import { SalaryReportDialogComponent } from '../salary-report-dialog/salary-report-dialog.component';
import { SharedServiceService } from 'src/app/services/shared-service.service';

@Component({
  selector: 'app-employee-salary-detail-table',
  templateUrl: './employee-salary-detail-table.component.html',
  styleUrls: ['./employee-salary-detail-table.component.css']
})
export class EmployeeSalaryDetailTableComponent implements OnInit {

  public employeeSalaryDatails: EmployeeSalary[];
  public displayedColumns: string[] = ['Employee Name', 'CTC', 'Paid Days', 'Basic',
    'Other Earning', 'Insentive/Bonus Per Month', 'PF', 'ESIC', 'ProfessionalTax', 'TDS', 'Other Deduction',
    'TD'];
  public dataSource: any;
  public searchByText = '';
  public isHoldVisible: boolean;
  public isLoading = true;
  public selectedFile: File = null;
  public years: any[] = [];
  public months: string[] = [];
  public selectedMonthForSearch: number = null;
  public selectedYearForSearch: number = null;
  private setMonthAndYear: Date = new Date();

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(private empSalaryDetService: EmployeeSalaryDetailsService, public dialog: MatDialog,
              private router: Router, private http: HttpClient, private sharedService: SharedServiceService) { }

  ngOnInit() {
    this.setDetailsForSearchByMonthAndYear();
    this.employeeSalaryDetails();
    // if (this.employeeSalaryDatails) {
    //   this.dataSource.sort = this.sort;
    // }
  }

  public employeeSalaryDetails(): void {
    this.empSalaryDetService.getEmployeeSalaryDetail(true, this.selectedMonthForSearch, this.selectedYearForSearch).
    subscribe(
      (data) => {
        this.employeeSalaryDatails = data;
        this.setMaterialTable(this.employeeSalaryDatails);
        this.isLoading = false;
      }
    );
  }

  public setDetailsForSearchByMonthAndYear(): void {
    this.years = this.sharedService.getYears(true);
    this.months = this.sharedService.getMonths();
    this.selectedMonthForSearch = this.setMonthAndYear.getMonth();
    this.selectedYearForSearch = this.setMonthAndYear.getFullYear();
  }

  // public holdEmployeeSalary(): void {
  //   if (this.isHoldVisible) {
  //     this.empSalaryDetService.getEmployeeSalaryDetail(true).subscribe(
  //       (data) => {
  //         this.employeeSalaryDatails = data;
  //         this.setMaterialTable(this.employeeSalaryDatails);
  //       }
  //     );
  //   } else {
  //     this.empSalaryDetService.getEmployeeSalaryDetail(false).subscribe(
  //       (data) => {
  //         this.employeeSalaryDatails = data;
  //         this.setMaterialTable(this.employeeSalaryDatails);
  //       }
  //     );
  //   }
  //   this.isHoldVisible = !this.isHoldVisible;
  // }

  private setMaterialTable(tableData: EmployeeSalary[]) {
    this.dataSource = new MatTableDataSource<EmployeeSalary>(tableData);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  public viewFullempployeeSalaryDetails(element: EmployeeSalary) {
    this.dialog.open(EmployeeSalaryDetailsDialogComponent, { data: element });
  }

  public applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  public resetSearchBox(): void {
    this.searchByText = '';
    this.setMaterialTable(this.employeeSalaryDatails);
  }

  public exportAsXLSX(): void {
    window.location.href =
    `http://192.168.1.235:8088/Reports/SalaryDetailsExcel/${this.selectedMonthForSearch}/${this.selectedYearForSearch}`;
  }

  public generateSalaryReport(): void {
    window.location.href =
    `http://192.168.1.235:8088/Reports/SalaryReportExcel/${this.selectedMonthForSearch}/${this.selectedYearForSearch}`;
  }

  public salaryCode(): void {
    this.router.navigate(['employee-salary-details/Create-Salary-Structure-Code']);
  }

  private removeUnimportedColumn(): void {
    this.employeeSalaryDatails.forEach(
      (data, index) => {
        delete this.employeeSalaryDatails[index].EmployeeId,
          delete this.employeeSalaryDatails[index].ResponceMessage;
        delete this.employeeSalaryDatails[index].Hold;
      });
  }

  public viewSalaryCode(): void {
    this.router.navigate(['employee-salary-details/View-Salary-Structure-Code']);
  }

  public appresialForm(): void {
    this.router.navigate(['employee-salary-details/appresial']);
  }

  public navigateToList(): void {
    this.router.navigate(['employee-salary-details']);
  }

  public onFileSelected(event): void {
    if (event.target.files.length > 0) {
      this.selectedFile = event.target.files[0];
    }
  }

  public downloadSalReport(): void {
    this.dialog.open(SalaryReportDialogComponent);
  }

  public importSalReport(): void {
    this.dialog.open(EmpSalReportUploadComponent);
  }

  // public onUpload(): void {
  //   const fd = new FormData();
  //   fd.append('file', this.selectedFile);
  //   this.empSalaryDetService.uploadExcleForAprDetails(fd).subscribe(
  //     (res) => { console.log(res); },
  //     (err) => { console.log(err); }
  //   );
  // }
}


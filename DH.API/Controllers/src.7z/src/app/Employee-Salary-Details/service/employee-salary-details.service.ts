import { Injectable } from '@angular/core';
import { BaseServiceService } from 'src/app/services/base-service.service';
import { SalayStructureCode } from '../models/salay-structure-code.model';
import { Observable } from 'rxjs';
import { Appresial } from '../../Employee-Register-Components/models/appresial.false';
import { EmployeeRegister } from 'src/app/Employee-Register-Components/models/employee-register';

@Injectable({
  providedIn: 'root'
})

export class EmployeeSalaryDetailsService {

  public viewSalaryCodeId: number = null;
  public empIdForAppresial: number = null;
  public isBackbtnVisible: boolean = true;
  public isForUpdate: boolean;
  public aprIdForUpdtAprDetails: number = null;
  public isAppraisalAmountVisibleForUnfix: boolean;

  constructor(private baseService: BaseServiceService) { }

  public getEmployeeDetailsById(id: number): Observable<EmployeeRegister[]> {
    return this.baseService.post(`EmployeeDetails/GetEmployee`, { id });
  }

  public getEmployeeSalaryDetail(onHold: boolean, month: number, year: number) {
    return this.baseService.get(`SalaryStruct/GetAllSalary/${month}/${year}`);
  }

  public getSalaryCode() {
    return this.baseService.get('SalaryStruct/GetStruct/0');
  }

  public updateSalaryCode(salaryForm: SalayStructureCode) {
    return this.baseService.put('SalaryStruct/UpdateStruct/' + salaryForm.StructureId, salaryForm);
  }

  public getSalaryCodeById(id: number) {
    return this.baseService.get('SalaryStruct/GetStruct/' + id);
  }

  public saveSalaryCode(salaryForm: SalayStructureCode) {
    return this.baseService.post('SalaryStruct/InsertStruct', salaryForm);
  }

  public deleteSalaryCode(id: number) {
    return this.baseService.delete('SalaryStruct/DeleteStruct', id);
  }

  public generateSalaryReport() {
    return this.baseService.get('Reports/SalaryReport');
  }

  public getEmpDetForAppresial(id: number): Observable<Appresial[]> {
    return this.baseService.get('AppraisalDetails/GetEmpLastAppraisal/' + id);
  }

  public saveAppresialDetails(appresialDetail: Appresial) {
    return this.baseService.post('AppraisalDetails/InsertAppraisal', appresialDetail);
  }

  public getEmpAprDetails(companyId: number, month: number, year: number): Observable<Appresial[]> {
    return this.baseService.get(`AppraisalDetails/GetDetailsByCompanyId/${companyId}/${month}/${year}`);
  }

  public getAprDetForUpdate(aId: number): Observable<Appresial[]> {
    return this.baseService.get('AppraisalDetails/GetAppraisal/' + aId);
  }

  public updateEmployeeApprDetFirstTime(employeeAprDetails: Appresial, employeeId: number) {
    return this.baseService.put(`AppraisalDetails/UpdateAppraisal/${employeeId}`, employeeAprDetails);
  }

}

import { Component, OnInit, ViewChild } from '@angular/core';
import { EmployeeSalaryDetailsService } from '../service/employee-salary-details.service';
import { SalayStructureCode } from '../models/salay-structure-code.model';
import { ToastrService } from 'ngx-toastr';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-salary-structure-code',
  templateUrl: './salary-structure-code.component.html',
  styleUrls: ['./salary-structure-code.component.css']
})
export class SalaryStructureCodeComponent implements OnInit {

  @ViewChild('refsalaryStructure', { static: true }) public createSalaryForm: NgForm;

  public salaryCodes: SalayStructureCode;

  salaryForm: SalayStructureCode = {
    StructureId: null,
    StructureCode: null,
    Basic: null,
    HRA: null,
    Medical: null,
    Conveyance: null,
    WebResearch: null,
    PfEmployee: null,
    PfEmployer: null,
    EsicEmployee: null,
    EsicEmployer: null,
    ProfessionalTax: null,
    OtherEarning: null,
    OtherDeduction: null,
    Incentive: null,
    TDS: null
  };

  constructor(private empSalaryDetService: EmployeeSalaryDetailsService, private toastr: ToastrService, private router: Router) { }

  ngOnInit() {
     if (this.empSalaryDetService.viewSalaryCodeId) {
       this.getSalaryCodeDetails(this.empSalaryDetService.viewSalaryCodeId);
     }
  }

  public getSalaryCodeDetails(id: number): void {
    if (id === 0) {
      this.salaryForm = {
        StructureId: null,
        StructureCode: null,
        Basic: null,
        HRA: null,
        Medical: null,
        Conveyance: null,
        WebResearch: null,
        PfEmployee: null,
        PfEmployer: null,
        EsicEmployee: null,
        EsicEmployer: null,
        ProfessionalTax: null,
        OtherEarning: null,
        OtherDeduction: null,
        Incentive: null,
        TDS: null
      };
    } else {
      this.getSalaryCodeById(id);
    }
  }

  public getSalaryCodeById(id: number): void {
    this.empSalaryDetService.getSalaryCodeById(id).subscribe(
      (data) => {
        this.salaryCodes = data;
        this.setSalaryCodeData();
      }
    );
  }

  public setSalaryCodeData(): void {
    this.salaryForm = this.salaryCodes[0];
    this.empSalaryDetService.viewSalaryCodeId = null;
  }

  public saveSalaryCode(): void {
    if (this.createSalaryForm.invalid) {
      return;
    } else {
      if (this.salaryForm.StructureId) {
        this.empSalaryDetService.updateSalaryCode(this.salaryForm).subscribe(
          (data) => {
            this.toastr.success('SalaryCode Updated Successfully');
            this.createSalaryForm.resetForm();
            this.router.navigate(['employee-salary-details/View-Salary-Structure-Code']);
          }
        );
      } else {
        this.empSalaryDetService.saveSalaryCode(this.salaryForm).subscribe(data => {
          this.toastr.success('Structure Added Successfully');
          this.createSalaryForm.resetForm();
        },
          error => {
            this.toastr.error('Invalid Structure');
            // this.createEmployeeForm.resetForm();
          }
        );
      }

    }
  }

  public back(): void {
    this.router.navigate(['employee-salary-details']);
  }

}

import { Component, OnInit } from '@angular/core';
import { EmployeeSalaryDetailsService } from '../service/employee-salary-details.service';
import { SalayStructureCode } from '../models/salay-structure-code.model';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-view-salary-code',
  templateUrl: './view-salary-code.component.html',
  styleUrls: ['./view-salary-code.component.css']
})
export class ViewSalaryCodeComponent implements OnInit {

  // displayedColumns: string[] = ['position', 'StructureCode', 'Operation'];
  // dataSource: SalayStructureCode;

  public displayedColumns = ['StructureCode', 'Basic', 'HRA', 'Medical', 'Conveyance', 'WebResearch', 'PfEmployee', 'PfEmployer',
                             'EsicEmployee', 'EsicEmployer', 'ProfessionalTax', 'OtherEarning', 'OtherDeduction', 'Incentive', 'TDS', 'id'];
  transactions: SalayStructureCode[];

  constructor(private empSalaryDetService: EmployeeSalaryDetailsService, private router: Router, private toastr: ToastrService) { }

  ngOnInit() {
    this.getSalaryCode();
  }

  public viewFullSalaryCodeDetails(id: number): void {
    this.empSalaryDetService.viewSalaryCodeId = id;
    this.router.navigate(['/employee-salary-details/Create-Salary-Structure-Code']);
  }

  public getSalaryCode(): void {
    this.empSalaryDetService.getSalaryCode().subscribe(
      (data) => {
        this.transactions = data;
      }
    );
  }

  public deleteSalaryCode(id: number): void {
    if (confirm('Are You Sure You Want To Delete?')) {
      this.empSalaryDetService.deleteSalaryCode(id).subscribe(
        (data) => {
          this.toastr.success('SalaryCode Deleted Successfully');
          this.getSalaryCode();
        }
      );
    }
  }

  public back(): void {
    this.router.navigate(['employee-salary-details']);
  }

}

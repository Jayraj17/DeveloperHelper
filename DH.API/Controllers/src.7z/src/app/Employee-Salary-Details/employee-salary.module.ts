import { NgModule } from '@angular/core';
import { EmployeeSalaryDetailTableComponent } from './employee-salary-detail-table/employee-salary-detail-table.component';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeSalaryDetailsDialogComponent } from './employee-salary-details-dialog/employee-salary-details-dialog.component';
import { SalaryStructureCodeComponent } from './salary-structure-code/salary-structure-code.component';
import { ViewSalaryCodeComponent } from './view-salary-code/view-salary-code.component';
import { SharedModule } from '../shared/shared.module';
import { EmpSalaryComListComponent } from './emp-salary-com-list/emp-salary-com-list.component';
import { EmpSalReportUploadComponent } from './emp-sal-report-upload-dialog/emp-sal-report-upload.component';
import { SalaryReportDialogComponent } from './salary-report-dialog/salary-report-dialog.component';


export const routes: Routes = [
  { path: '', component: EmpSalaryComListComponent },
  { path: 'employee-salary', component: EmployeeSalaryDetailTableComponent },
  { path: 'Create-Salary-Structure-Code', component: SalaryStructureCodeComponent },
  { path: 'View-Salary-Structure-Code', component: ViewSalaryCodeComponent },
  { path: '**', redirectTo: '', pathMatch: 'full' }
];

@NgModule({
  declarations: [
    EmployeeSalaryDetailTableComponent,
    EmployeeSalaryDetailsDialogComponent,
    SalaryStructureCodeComponent,
    ViewSalaryCodeComponent,
    EmpSalaryComListComponent,
    EmpSalReportUploadComponent,
    SalaryReportDialogComponent
  ],
  imports: [
    RouterModule.forChild(routes),
    SharedModule
  ],
  entryComponents: [
    EmployeeSalaryDetailsDialogComponent,
    EmpSalReportUploadComponent,
    SalaryReportDialogComponent
  ],
})
export class EmployeeSalaryModule { }

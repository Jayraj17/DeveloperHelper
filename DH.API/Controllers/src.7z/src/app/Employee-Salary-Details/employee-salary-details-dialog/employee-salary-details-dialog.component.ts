import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material';
import { EmployeeSalary } from '../models/employee-salary.model';

@Component({
  selector: 'app-employee-salary-details-dialog',
  templateUrl: './employee-salary-details-dialog.component.html',
  styleUrls: ['./employee-salary-details-dialog.component.css']
})
export class EmployeeSalaryDetailsDialogComponent implements OnInit {

  public employeeSalaryDetail: EmployeeSalary;

  constructor(@Inject(MAT_DIALOG_DATA) public data: EmployeeSalary) {}

  ngOnInit() {
    this.employeeSalaryDetail = this.data;
  }

}

import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef } from '@angular/material';
import { SharedServiceService } from 'src/app/services/shared-service.service';
import { environment } from 'src/environments/environment';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-salary-report-dialog',
  templateUrl: './salary-report-dialog.component.html',
  styleUrls: ['./salary-report-dialog.component.css']
})
export class SalaryReportDialogComponent implements OnInit {

  public selectedYear: number;
  public selectedMonth: number;
  public years: number[] = [];
  public months: any[] = [];

  @ViewChild('refGenerateUpComiAprReport', {static: true}) aprForm: NgForm;

  constructor(private dialogRef: MatDialogRef<SalaryReportDialogComponent>, private sharedService: SharedServiceService) { }

  ngOnInit() {
     this.months = this.sharedService.getMonths();
     this.years = this.sharedService.getYears(true);
  }

  downloadSalaryReport(): void {
    if (this.aprForm.invalid) {
        return;
    } else {
       window.location.href = `${environment.baseUrl}/Reports/InsertSalaryPaidDays/${this.selectedMonth}/${this.selectedYear}`;
       this.dialogRef.close();
    }
  }

}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-emp-salary-com-list',
  templateUrl: './emp-salary-com-list.component.html',
  styleUrls: ['./emp-salary-com-list.component.css']
})
export class EmpSalaryComListComponent implements OnInit {

  constructor(private route: Router) { }

  ngOnInit() {
  }

  public viewUpComAprDetails(): void {
    this.route.navigate(['/employee-salary-details/Apprasial-Details']);
  }

  public navigateToSalaryDetails(): void {
    this.route.navigate(['/employee-salary-details/employee-salary']);
  }

  public navigateToViewSalaryCode(): void {
    this.route.navigate(['/employee-salary-details/View-Salary-Structure-Code']);
  }

  public navigateToCreateSalaryCode(): void {
    this.route.navigate(['/employee-salary-details/Create-Salary-Structure-Code']);
  }

}

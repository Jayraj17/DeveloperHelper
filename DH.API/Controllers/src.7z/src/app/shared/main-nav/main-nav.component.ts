import { Component, OnDestroy, OnInit, AfterViewInit } from '@angular/core';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { UserService } from '../../signup-login/service/user.service';
import { BaseServiceService } from '../../services/base-service.service';
import { ToastrService } from 'ngx-toastr';
import { EmployeeRegisterService } from 'src/app/Employee-Register-Components/services/employee-register.service';

@Component({
  selector: 'app-main-nav',
  templateUrl: './main-nav.component.html',
  styleUrls: ['./main-nav.component.css']
})
export class MainNavComponent implements OnInit, AfterViewInit {

  // var header = document.getElementById('myDIV');
  // var btns = header.getElementsByClassName('common');
  // for (let i = 0; i < btns.length; i++) {
  //   btns[i].addEventListener('click', function () {
  //     var current = document.getElementsByClassName('active');
  //     current[0].className = current[0].className.replace(' active', '');
  //     this.className += " active";
  //   });
  // }

  private header: any;
  private btns: any;
  private i: number;

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches)
    );
  notifications: Notification[];
  private element: any;

  constructor(private breakpointObserver: BreakpointObserver,
              private router: Router,
              private user: UserService,
              private baseService: BaseServiceService,
              private toastr: ToastrService,
              private employeeRegSer: EmployeeRegisterService) { }

  ngOnInit() {
    // class="btn active"
    this.baseService.get('Reminder/CallReminder').subscribe(
      (data) => { this.notifications = data; }
    );
  }

  ngAfterViewInit() {
    this.header = document.getElementById('myDIV');
    this.btns = this.header.getElementsByClassName('common');
    for (this.i = 0; this.i < this.btns.length; this.i++) {
      this.btns[this.i].addEventListener('click', function() {
        this.current = document.getElementsByClassName('active');
        this.current[0].className = this.current[0].className.replace('active', '');
        this.className += ' active';
      });
    }
  }

  public addSystemUser(): void {
    this.router.navigate(['/signup']);
  }

  public Logout(): void {
    sessionStorage.removeItem('userToken');
    this.user.isLogin = false;
    this.employeeRegSer.isNotificationView = false;
    this.user.userToken = sessionStorage.getItem('userToken');
    this.router.navigate(['/Login']);
  }

  public navigateToDashboard(): void {
    this.router.navigate(['dashboard']);
  }

  public navigateToManage(): void {
    this.router.navigate(['manage']);
  }

  public navigateToEmployeeSalaryDetails(): void {
    this.router.navigate(['employee-salary-details']);
  }

  public navigateToOfficeExpence(): void {
    this.router.navigate(['office-expence']);
  }

  public navigateToChngePassword(): void {
    this.router.navigate(['changePassword']);
  }

  public navigateToOther(): void {
    this.router.navigate(['other']);
  }

  public navigateToApprasialDetails(): void {
    this.router.navigate(['employee-apprasial-details']);
  }

}

export class Notification {
  public ExpenseName: string;
  public Description: string;
}


import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, NavigationStart, Event } from '@angular/router';
import { UserService } from './signup-login/service/user.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'material';
  currentUrl: string;
  constructor(private route: Router, public user: UserService) {
   this.route.events.subscribe( (routerEvent: Event) => {
    if (routerEvent instanceof NavigationStart) {
      this.currentUrl = routerEvent.url;
    }
   });
  }
}

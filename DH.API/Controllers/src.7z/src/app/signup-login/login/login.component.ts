import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from 'src/app/signup-login/service/user.service';
import { HttpErrorResponse } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  // tslint:disable-next-line: ban-types
  public isLoginError: Boolean = false;
  public isLoading = false;
  public hide = true;

  constructor(private userService: UserService, private router: Router,
              private toastr: ToastrService, private route: ActivatedRoute) { }

  @ViewChild('loginForm', { static: true }) public loginFormData: NgForm;

  ngOnInit() {
  }

  public OnSubmit(userName, password) {
    if (this.loginFormData.invalid) {
      return;
    } else {
      this.isLoading = true;
      this.userService.userAuthentication(userName, password).subscribe((data: any) => {
        // localStorage.setItem('userToken', data.access_token);
        sessionStorage.setItem('userToken', data.access_token);
        this.userService.isLogin = true;
        this.userService.userToken = data.access_token;
        this.isLoading = false;
        this.router.navigate(['/dashboard']);
      },
        (err: HttpErrorResponse) => {
          if (err.statusText === 'Bad Request') {
            this.isLoading = false;
            this.toastr.error('Invalid Username And Password');
          } else {
            this.isLoading = false;
            this.toastr.error('Bad Server Connection');
          }
        });
    }
  }

}

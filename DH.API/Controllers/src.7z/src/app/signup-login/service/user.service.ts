import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from '../../models/user.model';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  serverUrl: string = environment.baseUrl;
  isLogin = false;
  userToken: string = sessionStorage.getItem('userToken');

  constructor(private http: HttpClient) { }

  // For User Registration

  registerUser(user: User) {
    const body: User = {
      FirstName: user.FirstName,
      LastName: user.LastName,
      UserName: user.UserName,
      Password: user.Password,
      Email: user.Email
    };
    return this.http.post(this.serverUrl + '/api/user/Register', body);
  }

  // For User Authentication by UserName and Password.
  userAuthentication(username, password) {
    const data = 'username=' + username + '&password=' + password + '&grant_type=password';
    const reqHeader = new HttpHeaders({'Content-type': 'application/x-www-urlencoded', 'auth-header': 'true'});
    // token request
    return this.http.post(this.serverUrl + '/token', data, {headers : reqHeader});
  }
}

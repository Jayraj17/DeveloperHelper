import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { User } from 'src/app/models/user.model';
import { UserService } from 'src/app/signup-login/service/user.service';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  Signup: User = {
    FirstName: null,
    LastName: null,
    Email: null,
    UserName: null,
    Password: null
  };
  @ViewChild('signUpForm', {static: true}) public signUpFormData: NgForm;

  constructor(private userService: UserService, private toastr: ToastrService, private router: ActivatedRoute) {
  }

  ngOnInit() {

  }

  OnSubmit() {
    if (this.signUpFormData.invalid) {
      return;
    } else {
      this.userService.registerUser(this.signUpFormData.value).subscribe((data: any) => {
        if (data.Succeeded === true) {
          this.signUpFormData.resetForm();
          this.toastr.success('Registered Successfully...!!!');
        } else {
          this.toastr.error('Username or Email already Exits');
        }
      }, (err) => {
        this.toastr.error('Username or Email already Exits');
      });
    }
  }


}

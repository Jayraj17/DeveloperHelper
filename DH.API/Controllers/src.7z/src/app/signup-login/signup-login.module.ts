import { NgModule } from '@angular/core';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  declarations: [
    ChangePasswordComponent,
    LoginComponent,
    SignupComponent
  ],
  imports: [
    SharedModule
  ]
})
export class SignupLoginModule { }

import { Component, OnInit, ViewChild } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  @ViewChild('changePasswordForm', {static: true}) public changePasswordForm: NgForm;

  constructor(private toastr: ToastrService, private route: Router) {
   }

  ngOnInit() {
  }
  showToaster() {
    this.toastr.success('Password Change Successfully');
    this.route.navigate(['']);
  }

  public changePassword(): void {
    if (this.changePasswordForm.invalid) {
      return;
    } else {

    }
  }
}

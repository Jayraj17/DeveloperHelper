import { Injectable } from '@angular/core';
import { BaseServiceService } from '../services/base-service.service';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  constructor(private baseServise: BaseServiceService) { }

  public getNotification() {
    return this.baseServise.get('Reminder/CallReminder');
  }

}

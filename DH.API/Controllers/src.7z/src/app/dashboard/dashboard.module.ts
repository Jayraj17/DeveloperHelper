import { NgModule } from '@angular/core';
import { DashboardComponent } from './dashboard.component';
import { FigurecardComponent } from './figurecard/figurecard.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../shared/shared.module';

export const routes: Routes = [
  { path: '', component: DashboardComponent, data: { title : 'Payroll - Dashboard' }},
];

@NgModule({
  declarations: [
    DashboardComponent,
    FigurecardComponent
  ],
  imports: [
    RouterModule.forChild(routes),
    SharedModule
  ]
})
export class DashboardModule { }

import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, CanActivate, Router } from '@angular/router';
import { UserService } from '../../signup-login/service/user.service';

@Injectable({
  providedIn: 'root'
})
export class LoginAuthGuard implements CanActivate {
  constructor(private user: UserService, private route: Router) {}
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot ): boolean {
     if (sessionStorage.getItem('userToken')) {
        this.route.navigate(['dashboard']);
        return false;
     } else {
       return true;
     }
  }
}

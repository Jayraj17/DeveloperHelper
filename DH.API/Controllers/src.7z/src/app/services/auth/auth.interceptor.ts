import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Router } from '@angular/router';

export class AuthInterceptor implements HttpInterceptor {

    constructor(private router: Router) { }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        if (req.headers.get('auth-header') === 'true') {
            return next.handle(req.clone());
        }

        if (sessionStorage.getItem('userToken') !== null) {
            const newclone = req.clone({
                // headers : req.headers.set('Authorization','Bearer '+ localStorage.getItem('userToken'))
                setHeaders: { Authorization: 'Bearer ' + sessionStorage.getItem('userToken') }
            });
            return next.handle(newclone).pipe(tap(succ => { },
                err => {
                    if (err.status === 401) {
                        this.router.navigateByUrl('/login');
                    }
                }
            ));
        } else {
            this.router.navigateByUrl('/login');
        }
    }
}

import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, CanActivate, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { UserService } from '../../signup-login/service/user.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  constructor(private router: Router, private user: UserService) {}
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot ): boolean {
    if (sessionStorage.getItem('userToken') != null && sessionStorage.getItem('userToken') === this.user.userToken) {
      return true;
    }
    this.router.navigate(['/Login']);
    return false;

  }
}
// && localStorage.getItem('userToken') === this.user.userToken

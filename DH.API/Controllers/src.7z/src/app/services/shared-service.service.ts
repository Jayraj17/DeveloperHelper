import { Injectable } from '@angular/core';
import { Appresial } from '../Employee-Register-Components/models/appresial.false';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { ToastrService } from 'ngx-toastr';
import { BaseServiceService } from './base-service.service';
import { Observable } from 'rxjs';
import { Designation } from '../models/designation.model';


@Injectable({
  providedIn: 'root'
})
export class SharedServiceService {

  private startingYear: number = 2016;
  private startingYearCopy: number = this.startingYear;
  private year: any[] = [];
  private date: Date = new Date();
  private appraisalId: number = null;
  private getLength: number;
  private months: string[] =
  ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'Octomber', 'November', 'December'];
  // private urlForUploadSalReport: string = 'http://192.168.1.235:8088/Reports/ImportSalarySheet';  url for upload salary report
  // private urlForUploadAprReport: string = `${environment.baseUrl}Reports/UploadExcle`;  for upload appraisal report
  private urlForUploadFile: string = null;

  public errMsgForFileUpload: string = 'Error while uploading file.';


  constructor(private http: HttpClient, private tosatrService: ToastrService,
              private baseService: BaseServiceService) { }

  public GetDepartment() {
    return this.baseService.get('EmployeeDetails/GetDepartment');
  }

  public GetDesignation(): Observable<Designation[]> {
    return this.baseService.get('EmployeeDetails/GetDesignation');
  }

  public getCompanyCodes() {
    return this.baseService.get('ExpenseDetails/GetCompanyId');
  }

  public uploadFile(file: FormData, url: string, methodType: number) {

    if (url === null) {
       this.tosatrService.error('Please select file.');
       return;
    }
    this.urlForUploadFile = `${environment.baseUrl}${url}`;
    // tslint:disable-next-line: prefer-const
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Accept', 'application/json');
    // tslint:disable-next-line: object-literal-shorthand
    const httpOptions = { headers: headers };

    switch (methodType) {
        case 1:  return this.http.post(this.urlForUploadFile, file, httpOptions);
                 break;

        case 2:  return this.http.put(this.urlForUploadFile, file, httpOptions);
                 break;

        default: this.tosatrService.error('Bad request.');
                 break;
    }

  }

  // function take boolean type of argument if true than return starting yesr to current and if
  // false than return starting year to specified year in requirement

  public getYears(status: boolean): any[] {
    if (status) {
      return this.setYears(this.startingYear);
    } else {
      return this.setYearForAppraisal(this.startingYear);
    }
  }

  public getMonths(): any[] {
    return this.months;
  }

  // this function return year but only retutn starting yesr to current year not return any upcoming year

  private setYears(startingYesr: number): any[] {
    this.filterArrayForNewValue();
    for (this.startingYear; this.startingYear <= this.date.getFullYear(); this.startingYear++) {
      this.year.push(this.startingYear);
    }
    return this.year;
  }

  // this function is return year but only used for appraisal because there are couple of
  //  chances we need upcoming 2 - 3 year for appraisal details

  private setYearForAppraisal(startingYear: number) {
    this.filterArrayForNewValue();
    for (this.startingYear; this.startingYear <= this.date.getFullYear() + 3; this.startingYear++) {
      this.year.push(this.startingYear);
    }
    return this.year;
  }

  private filterArrayForNewValue(): void {
    if (!this.year || this.year.length !== 0) {
      this.year = [];
      this.startingYear = this.startingYearCopy;
    }
  }

  public getNewDate(date: Date): Date {
    if (!date && date !== null) {
      return new Date(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), date.getUTCHours(),
        date.getUTCMinutes(), date.getUTCSeconds());
    }
  }

  public setLastAppraisialEditable(employeeAppraisalDetails: Appresial[]): Appresial[] {
     this.appraisalId = null;
     return this.findLastAppraisalId(employeeAppraisalDetails);
  }

  public findLastAppraisalId(employeeAppraisalDetails: Appresial[]): Appresial[] {
    if (employeeAppraisalDetails && employeeAppraisalDetails.length !== 0)  {
       employeeAppraisalDetails.forEach(apprsisalDetails => {
          if (apprsisalDetails.Status && apprsisalDetails.Status === true) {
             this.appraisalId = apprsisalDetails.AprId;
          }
       });
       if (this.appraisalId) {
        return this.setLastAppraisalEditable(this.appraisalId, employeeAppraisalDetails);
       } else {
         return employeeAppraisalDetails;
       }
    }
  }

  private setLastAppraisalEditable(aId: number, employeeAppraisalDetails: Appresial[]) {
    if (employeeAppraisalDetails) {
       if (aId) {
          for (this.getLength = 0; this.getLength <= employeeAppraisalDetails.length; this.getLength++) {
              if (employeeAppraisalDetails[this.getLength].AprId === aId) {
                  employeeAppraisalDetails[this.getLength].Status = null;
                  employeeAppraisalDetails[this.getLength].isActiveSalary = true;
                  return employeeAppraisalDetails;
              }
          }
       }
    }
  }

}

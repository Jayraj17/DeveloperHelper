import { Injectable } from '@angular/core';
import { CanDeactivate } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class EmployeeRegisterCanDeactiveGuardService implements CanDeactivate<any> {

  constructor() { }
  canDeactivate(component): boolean {
    if (component.createEmployeeForm.dirty) {
      return confirm('Are you sure you want to discard your changes?');
    }
    return true;
  }

}

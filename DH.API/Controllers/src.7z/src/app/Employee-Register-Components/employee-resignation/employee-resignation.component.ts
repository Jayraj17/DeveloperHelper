import { Component, OnInit, ViewChild, OnChanges } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeRegisterService } from '../services/employee-register.service';
import { EmployeeRegister } from 'src/app/Employee-Register-Components/models/employee-register';
import { Resignation } from 'src/app/Employee-Register-Components/models/resignation.model';
import { NgForm } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-employee-resignation',
  templateUrl: './employee-resignation.component.html',
  styleUrls: ['./employee-resignation.component.css']
})
export class EmployeeResignationComponent implements OnInit {

  public employeeName: string;
  public employeeDesignation: string;
  public employeeDepartment: string;
  public someDate = new Date();
  public numberOfDaysToAdd = 45;
  public isUpdate: boolean;

  public employeeData: EmployeeRegister;
  public employeeRelivingData: Resignation = {
    EmpId: null,
    ApplyDate: null,
    LeavingDate: null,
    ReasonOfResign: null,
    RejoinDate: null,
    EmployeeName: null,
    DepartmentName: null,
    DesignationName: null,
    DateOfJoining: null,
    IsRejoin: null
  };

  @ViewChild('employee', {static: true}) public createEmployeeForm: NgForm;

  constructor(private employeeRegSer: EmployeeRegisterService, private router: Router,
              private toastr: ToastrService) { }

  ngOnInit() {
    // this.aroute.paramMap.subscribe( paramMap => {
    //   const id = +paramMap.get('id');
    //   this.getEmployeeDetails(id);
    // });
    // 4
    this.employeeRegSer.employeeIdForResignation = 4;
    if (this.employeeRegSer.employeeIdForResignation) {
       this.getEmployeeDetails(this.employeeRegSer.employeeIdForResignation);
       this.employeeRegSer.employeeIdForResignation = null;
    } else {
      this.router.navigate(['manage']);
    }
    this.someDate.setDate(this.someDate.getDate() + this.numberOfDaysToAdd);
  }

  private getEmployeeDetails(id: number): void {
    this.employeeRegSer.getEmployeeResignationDetailsById(id).subscribe(
      (data) => {
        if (data.length > 0) {
           this.employeeData = data;
           this.employeeRelivingData = this.employeeData[0];
           this.isUpdate = true;
        } else {
          this.employeeRegSer.GetEmployeeById(id).subscribe(
            (dataOne) => {
              this.employeeData = dataOne;
              this.employeeRelivingData.EmpId = this.employeeData[0].EmpId;
            }
          );
        }
      }
    );
  }

  public saveResignationDetails(): void {
    if (this.createEmployeeForm.invalid) {
      return;
    } else {
      if (this.isUpdate) {
        this.updateResignationDetails();
      } else {
        this.insertResignationDetails();
      }
    }
  }

  public insertResignationDetails(): void {
    this.employeeRegSer.insertEmployeeResignationDetails(this.employeeRelivingData).subscribe(
      (data) => {
        this.toastr.success('Resignation Details Added Successfully');
        this.createEmployeeForm.resetForm();
        this.router.navigate(['manage/resignation-employee']);
      }
    );
  }

  public updateResignationDetails(): void {
    this.employeeRegSer.updateEmployeeResignationDetails(this.employeeRelivingData).subscribe(
      (data) => {
        this.toastr.success('Resignation Details Updated Successfully');
        this.createEmployeeForm.resetForm();
        this.isUpdate = false;
        this.router.navigate(['manage/resignation-employee']);
      }
    );
  }

  public deleteEmployeeResignationDetails(): void {
    if (confirm('Are you sure you want to delete employee?')) {
      this.employeeRegSer.deleteEmployeeResignationDetails(this.employeeRelivingData.EmpId).subscribe(
        (data) => {
          this.toastr.success('Resignation Details Deleted Successfully');
          this.router.navigate(['manage/resignation-employee']);
        }
      );
    }
  }

  public back(): void {
    this.employeeRegSer.employeeIdForResignation = null;
    if (this.isUpdate) {
       this.router.navigate(['manage/resignation-employee']);
    } else {
      this.router.navigate(['manage/employee-details']);
    }
  }
}

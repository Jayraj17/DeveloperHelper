import { Component, OnInit, ViewChild } from '@angular/core';
import { EmployeeRegisterService } from '../services/employee-register.service';
import { Resignation } from 'src/app/Employee-Register-Components/models/resignation.model';
import { MatPaginator, MatTableDataSource, MatSort } from '@angular/material';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-resignation-employee',
  templateUrl: './view-resignation-employee.component.html',
  styleUrls: ['./view-resignation-employee.component.css']
})
export class ViewResignationEmployeeComponent implements OnInit {

  public employeeResignationDetails: Resignation[];
  public isLoading = true;

  public displayedColumns: string[] = ['EmployeeName', 'DesignationName', 'DepartmentName', 'DateOfJoining',
                                       'ApplyDate', 'LeavingDate', 'EmpId'];
  public dataSource: any;
  public searchByText = '';

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  constructor(private employeeRegService: EmployeeRegisterService, private route: Router) { }

  ngOnInit() {
    this.employeeRegService.getEmployeeResignationDetails().subscribe(
      (data) => {
        this.employeeResignationDetails = data;
        this.setMaterialTable(this.employeeResignationDetails);
        this.isLoading = false;
       }
    );
  }

  private setMaterialTable(tableData: Resignation[]) {
    this.dataSource = new MatTableDataSource<Resignation>(tableData);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  public back(): void {
   this.route.navigate(['manage']);
  }

  public applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  public resetSearchBox(): void {
    this.searchByText = '';
    this.setMaterialTable(this.employeeResignationDetails);
  }

  public resignationPage(id: number): void {
    this.employeeRegService.employeeIdForResignation = id;
    this.route.navigate(['manage/resignation']);
  }
}

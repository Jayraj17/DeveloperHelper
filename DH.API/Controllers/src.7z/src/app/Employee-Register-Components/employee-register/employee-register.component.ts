import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { NgForm, FormGroup } from '@angular/forms';
import { EmployeeRegister } from '../models/employee-register';
import { ToastrService } from 'ngx-toastr';
import { Router, ActivatedRoute } from '@angular/router';
import { Department } from 'src/app/models/department.model';
import { Designation } from 'src/app/models/designation.model';
import { Title } from '@angular/platform-browser';
import { SalayStructureCode } from 'src/app/Employee-Salary-Details/models/salay-structure-code.model';
import { EmployeeSalaryDetailsService } from 'src/app/Employee-Salary-Details/service/employee-salary-details.service';
import { EmployeeRegisterService } from 'src/app/Employee-Register-Components/services/employee-register.service';
import { Companycode } from 'src/app/models/companycode';
import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';
import { Appresial } from '../models/appresial.false';
import { SharedServiceService } from 'src/app/services/shared-service.service';

export interface Food {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-employee-register',
  templateUrl: './employee-register.component.html',
  styleUrls: ['./employee-register.component.css'],
  providers: [{
    provide: STEPPER_GLOBAL_OPTIONS, useValue: { showError: true },
  }]
})
export class EmployeeRegisterComponent implements OnInit {

  @ViewChild('employee', { static: true }) public createEmployeeForm: NgForm;

  public departments: Department[];
  public designations: Designation[];
  public salaryCodes: SalayStructureCode[];
  private employeeIdForAppraisalDetails: number;
  public employeeAppresialDetails: Appresial = {
    AppraisalAmount: null,
    AprMonth: null,
    AprType: null,
    AprYear: null,
    DateOfJoining: null,
    DepartmentId: null,
    DesignationId: null,
    EmpId: null,
    EmployeeName: null,
    Salary: null,
    Comment: null,
    DepartmentName: null,
    DesignationName: null,
    SalaryCTC: null,
    UpdatedCTC: null
  };
  public companyCodes: Companycode;
  public testDate: Date;

  public employeeForm: EmployeeRegister = {
    EmpId: null,
    EmployeeName: null,
    DateOfJoining: null,
    DesignationId: null,
    DesignationName: null,
    DepartmentName: null,
    DepartmentId: null,
    PersonalEmail: null,
    CompanyEmail: null,
    Salary: null,
    SalaryCode: null,
    PfNumber: null,
    EsicNumebr: null,
    PanNumber: null,
    UanNumber: null,
    AdharNumber: null,
    CompanyId: null,
    CompanyName: null,
    BankAccountNo: null,
    PaymentMode: null,
    Hold: false,
    Bonus: false,
    DateOfReJoining: null,
    LeavingDate: null,
    CreatedOn: null,
    CreatedBy: null,
    IsActive: null,
    IsDelete: null,
    UpdatedOn: null,
    UpdatedBy: null
  };

  constructor(private employeeRegService: EmployeeRegisterService, private toastr: ToastrService,
              private route: Router, private title: Title, private empSalaryDetService: EmployeeSalaryDetailsService,
              private sharedService: SharedServiceService) { }

  ngOnInit() {
    if (this.employeeRegService.editEmployeeId) {
      this.getEmployee(this.employeeRegService.editEmployeeId);
      this.employeeRegService.editEmployeeId = null;
    }
    this.sharedService.GetDepartment().subscribe(
      (data) => {
        this.departments = data;
      }
    );
    this.sharedService.GetDesignation().subscribe(
      (data) => {
        this.designations = data;
      }
    );
    this.employeeRegService.getSalaryCode().subscribe(
      (data) => {
        this.salaryCodes = data;
      }
    );
    this.sharedService.getCompanyCodes().subscribe(
      (data) => {
        this.companyCodes = data;
      }
    );
  }

  public getEmployee(id: number): void {
    if (id === null) {
      this.employeeForm = null;
      this.createEmployeeForm.reset();
    } else {
      this.employeeRegService.GetEmployeeById(id).subscribe((data: EmployeeRegister) => {
        this.employeeForm = data[0];
      });
    }
  }

  public saveEmployee(): void {

    if (this.createEmployeeForm.invalid) {
      return;
    }

    if (!this.employeeForm.EmpId) {
      this.employeeRegService.RegisterEmployee(this.employeeForm).subscribe(data => {
        this.empSalaryDetService.isBackbtnVisible = false;
        this.employeeIdForAppraisalDetails = data.EmpId;
        this.empSalaryDetService.empIdForAppresial = data.UanNumber;
        this.setEmployeeAppresialDetails();
      },
        error => {
          this.toastr.error('Email is already exits.');
        }
      );
    } else {
      // this.employeeForm.DateOfJoining = this.sharedService.getNewDate(this.employeeForm.DateOfJoining);
      this.employeeRegService.UpdateEmployee(this.employeeForm.EmpId, this.employeeForm).subscribe(
        (data) => {
          this.toastr.success('Detail Updated Successfully'),
          this.createEmployeeForm.resetForm();
          this.route.navigate(['manage/employee-details']);
        }
      );
    }
    // this.createEmployeeForm.reset();
  }

  public setEmployeeAppresialDetails(): void {
    this.employeeAppresialDetails.EmpId = this.employeeIdForAppraisalDetails;
    this.employeeAppresialDetails.EmployeeName = this.employeeForm.EmployeeName;
    this.employeeAppresialDetails.DateOfJoining = this.employeeForm.DateOfJoining;
    this.employeeAppresialDetails.DesignationId = this.employeeForm.DesignationId;
    this.employeeAppresialDetails.DepartmentId = this.employeeForm.DepartmentId;
    this.employeeAppresialDetails.CompanyId = this.employeeForm.CompanyId;
    this.employeeAppresialDetails.Salary = this.employeeForm.Salary;
    this.employeeAppresialDetails.UanNumber = this.employeeForm.UanNumber;
    this.employeeRegService.addEmployeeApprDetFirstTime(this.employeeAppresialDetails).subscribe(
      (data: any) => {
        this.toastr.success('Employee Added Successfully');
        this.createEmployeeForm.resetForm();
        if (!confirm('Save without appresial details?')) {
           this.route.navigate(['manage/appraisal']);
        } else {
          this.route.navigate(['employee-details']);
        }
      }
    );
  }

  public back(): void {
    if (this.employeeForm.EmpId) {
      this.route.navigate(['manage/employee-details']);
    } else {
      this.route.navigate(['manage']);
    }
  }
}

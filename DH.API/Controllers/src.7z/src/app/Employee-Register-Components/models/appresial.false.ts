export class Appresial {
   public AprId?: number;
   public EmpId?: number;
   public EmployeeName: string;
   public DateOfJoining: Date;
   public DesignationId: number;
   public DesignationName: string;
   public DepartmentId: number;
   public DepartmentName: string;
   public AprType: boolean;
   public CompanyId?: number;
   public companyName?: string;
   public AprMonth: number;
   public AprYear: number;
   public Salary: string;
   public AppraisalAmount: number;
   public Comment: string;
   public SalaryCTC: number;
   public UpdatedCTC: number;
   public Status?: any;
   public UanNumber?: number;
   public isActiveSalary?: boolean;
}

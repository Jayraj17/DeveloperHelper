export class Resignation {
    public EmpId?: number;
    public ApplyDate: Date;
    public LeavingDate: Date;
    public ReasonOfResign: string;
    public IsRejoin: boolean;
    public RejoinDate: Date;
    public EmployeeName: string;
    public DepartmentName: string;
    public DesignationName: string;
    public DateOfJoining: Date;
}

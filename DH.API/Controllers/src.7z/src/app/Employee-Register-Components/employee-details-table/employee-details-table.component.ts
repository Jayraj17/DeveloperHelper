import { Component, OnInit, ViewChild, OnDestroy, AfterViewInit } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort, MatDialog } from '@angular/material';
import { EmployeeRegisterService } from 'src/app/Employee-Register-Components/services/employee-register.service';
import { EmployeeRegister } from 'src/app/Employee-Register-Components/models/employee-register';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { Department } from 'src/app/models/department.model';
import { EmployeeListComponent } from '../employee-list/employee-list.component';
import { Subscription } from 'rxjs';
import { EmployeeAppraisalDetailsComponent } from '../employee-appraisal-details/employee-appraisal-details.component';
import { EmployeeSalaryDetailsService } from 'src/app/Employee-Salary-Details/service/employee-salary-details.service';
import { SharedServiceService } from 'src/app/services/shared-service.service';

@Component({
  selector: 'app-employee-details-table',
  templateUrl: './employee-details-table.component.html',
  styleUrls: ['./employee-details-table.component.css']
})
export class EmployeeDetailsTableComponent implements OnInit {

  public employeeData: EmployeeRegister[];
  private copyEmployeeData: EmployeeRegister[];
  public displayedColumns: string[] = ['EmployeeName', 'DateOfJoining', 'DesignationName', 'DepartmentName', 'CompanyCode',
    'PersonalEmail', 'CompanyEmail', 'Salary', 'EmpId', 'CompanyId'];
  dataSource: any = new MatTableDataSource<any>();
  public selectedDepartment: number[];
  public selectedDepartmentStringId: string = null;
  public departments: Department[];
  public searchByText = '';
  public isLoading = true;

  public subscription: Subscription;

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(private employeeRegService: EmployeeRegisterService,
              private toastr: ToastrService, private route: Router,
              public dialog: MatDialog, private empSalaryDetService: EmployeeSalaryDetailsService,
              public sharedService: SharedServiceService) { }

  ngOnInit() {
    this.sharedService.GetDepartment().subscribe(
      (data) => {
        this.departments = data;
      }
    );
    this.employeeRegService.GetEmployee().subscribe(
      (data: EmployeeRegister[]) => {
        this.employeeData = data,
        this.setMaterialTable(this.employeeData);
        this.isLoading = false;
      }
    );
    if (this.employeeData) {
      this.dataSource.sort = this.sort;
    }
  }

  public editEmployeeDetails(employeeId: number): void {
    this.employeeRegService.editEmployeeId = employeeId;
    this.route.navigate(['manage/register']);
  }

  public sortEmployeeByStatus(): void {
  }

  public deleteEmployeeDetails(employeeId: number): void {
    if (confirm('Are You Sure You Want To Delete?')) {
      this.employeeRegService.DeleteEmployee(employeeId).subscribe(data => {
        this.employeeRegService.GetEmployee().subscribe(
          (EmployeeData) => {
            this.employeeData = EmployeeData;
            this.setMaterialTable(this.employeeData);
          }
        );
        this.toastr.success('Employee Deleted Successfully');
      });
    }
  }

  public searchByDepartment(): void {
    if (this.selectedDepartment) {
      this.selectedDepartmentStringId = this.selectedDepartment.toString();
      this.employeeRegService.GetEmployeeByDepartment(this.selectedDepartmentStringId).subscribe(
        (data) => {
          this.employeeData = data,
            this.setMaterialTable(this.employeeData);
          // this.setMaterialTable(this.employeeData);
        }
      );
    }
  }

  private setMaterialTable(tableData: EmployeeRegister[]) {
    this.dataSource = new MatTableDataSource<EmployeeRegister>(tableData);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  public exportAsXLSX(): void {
    console.log(this.selectedDepartmentStringId);
    window.location.href = 'http://192.168.1.235:8088/Reports/EmployeeDetailsExcel?deptIdStr=' + this.selectedDepartmentStringId;
  }

  public showEmployeeDetail(employeeData: EmployeeRegister): void {
    this.dialog.open(EmployeeListComponent, { data: { employeeDetails: employeeData } });
  }

  private removeUnimportedColumn(employeeData: EmployeeRegister[]): void {
    this.employeeData.forEach(
      (data, index) => {
        delete this.employeeData[index].EmpId,
          delete this.employeeData[index].DateOfJoining,
          delete this.employeeData[index].DesignationId,
          delete this.employeeData[index].DepartmentId,
          delete this.employeeData[index].SalaryCode,
          delete this.employeeData[index].CreatedBy,
          delete this.employeeData[index].CreatedOn,
          delete this.employeeData[index].UpdatedBy,
          delete this.employeeData[index].UpdatedOn,
          delete this.employeeData[index].IsActive,
          delete this.employeeData[index].IsDelete;
      });
  }

  public viewEmployeIncrementHistory(eId: number, ename: string) {
    this.dialog.open(EmployeeAppraisalDetailsComponent, {data: { employeeId: eId, employeeName: ename}});
  }

  public navigateToList(): void {
    this.route.navigate(['manage']);
  }

  public applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  public resetSearchBox(): void {
    this.searchByText = '';
    this.setMaterialTable(this.employeeData);
  }

  public employeeRegister(): void {
    this.route.navigate(['manage/register']);
  }

  public viewEmployeAppraisal(eId: number): void {
    this.empSalaryDetService.empIdForAppresial = eId;
    this.empSalaryDetService.isForUpdate = true;
    this.route.navigate(['manage/appraisal']);
  }

}


import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { EmployeeSalaryDetailsService } from '../../Employee-Salary-Details/service/employee-salary-details.service';
import { ToastrService } from 'ngx-toastr';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { EmployeeRegister } from 'src/app/Employee-Register-Components/models/employee-register';
import { Appresial } from '../models/appresial.false';
import { forkJoin } from 'rxjs';
import { SharedServiceService } from 'src/app/services/shared-service.service';

@Component({
  selector: 'app-employee-appresial',
  templateUrl: './employee-appresial.component.html',
  styleUrls: ['./employee-appresial.component.css']
})
export class EmployeeAppresialComponent implements OnInit, OnDestroy {

  private employeeId: number;
  public appresialType: boolean;
  public years: number[] = [];
  public firstTime: boolean = false;
  public isMultipleEntry: boolean = false;
  public isForUpdate: boolean;
  public months: any[] = [];
  public isAprAmountAlwaysVisible: boolean = false;
  public employeeDetails: Appresial[] = [{
    AppraisalAmount: null,
    AprMonth: null,
    AprType: null,
    AprYear: null,
    DateOfJoining: null,
    DepartmentId: null,
    DesignationId: null,
    EmpId: null,
    EmployeeName: null,
    Salary: null,
    Comment: null,
    DepartmentName: null,
    DesignationName: null,
    SalaryCTC: null,
    UpdatedCTC: null
  }];
  public employeenewAppresialDet: Appresial = {
    AppraisalAmount: null,
    AprMonth: null,
    AprType: null,
    AprYear: null,
    DateOfJoining: null,
    DepartmentId: null,
    DesignationId: null,
    EmpId: null,
    EmployeeName: null,
    Salary: null,
    Comment: null,
    DepartmentName: null,
    DesignationName: null,
    SalaryCTC: null,
    UpdatedCTC: null
  };
  // create object for static dropdown
  public aprTypes: object = [{
    id: true, // Fix appraisal and fix amount with fix month
    label: 'Fix'
  }, {
    id: false, // unFix 0 mean appraisal time fix but amount is not fix
    label: 'Unfix'
  }];

  @ViewChild('appresialForm', { static: true }) public refAppresialForm: NgForm;

  constructor(public empSalaryDetService: EmployeeSalaryDetailsService, private toastr: ToastrService, private router: Router,
              public sharedService: SharedServiceService) { }

  ngOnInit() {
    this.months = this.sharedService.getMonths();
    this.years = this.sharedService.getYears(false);
    if (this.empSalaryDetService.isAppraisalAmountVisibleForUnfix && this.empSalaryDetService.isAppraisalAmountVisibleForUnfix === true) {
       this.isAprAmountAlwaysVisible = true;
    }
    // this.empSalaryDetService.isBackbtnVisible = false;
    if (this.empSalaryDetService.aprIdForUpdtAprDetails) {
      this.isForUpdate = true;
      this.updateAppraisalDetails(this.empSalaryDetService.aprIdForUpdtAprDetails);
    } else if (this.empSalaryDetService.empIdForAppresial) {
      this.employeeId = this.empSalaryDetService.empIdForAppresial;
      this.setEmployeeDetails(this.employeeId);
    } else {
      this.router.navigate(['manage/employee-details']);
    }
  }

  // AppraisalDetails/GetEmpLastAppraisal/10

  private setEmployeeDetails(eId: number): void {
    if (this.employeeId && this.employeeId !== null) {
      this.empSalaryDetService.getEmpDetForAppresial(this.employeeId).subscribe(
        (data: Appresial[]) => {
          if (data.length === 0) {
            this.toastr.error('Bad request');
          } else {
            this.employeeDetails[0] = data[0];
          }

          if (!data[0].AprMonth && !data[0].AprType) {
            this.firstTime = true;
          } else {
            this.firstTime = false;
          }

        }
      );
    } else {
      this.router.navigate(['manage/employee-details']);
    }
  }

  public updateAppraisalDetails(aId: number): void {
    this.empSalaryDetService.getAprDetForUpdate(aId).subscribe(
      (data: Appresial[]) => {
        this.employeeDetails[0].EmpId = data[0].EmpId;
        this.employeeDetails[0].EmployeeName = data[0].EmployeeName;
        this.employeeDetails[0].DateOfJoining = data[0].DateOfJoining;
        this.employeeDetails[0].DesignationName = data[0].DesignationName;
        this.employeeDetails[0].DepartmentId = data[0].DepartmentId;
        this.employeeDetails[0].DepartmentName = data[0].DepartmentName;
        this.employeeDetails[0].DesignationId = data[0].DesignationId;
        this.employeeDetails[0].Salary = data[0].Salary;
        this.employeeDetails[0].CompanyId = data[0].CompanyId;
        this.employeeDetails[0].AprType = data[0].AprType;
        this.employeeDetails[0].UanNumber = data[0].UanNumber;
        this.employeenewAppresialDet.AppraisalAmount = data[0].AppraisalAmount;
        this.employeenewAppresialDet.AprMonth = data[0].AprMonth;
        this.employeenewAppresialDet.AprYear = data[0].AprYear;
        this.employeenewAppresialDet.Comment = data[0].Comment;
      }
    );
  }

  public saveAppresialDetails(): void {
    if (this.refAppresialForm.invalid) {
      return;
    } else {
      if ((this.employeeDetails[0].AprType === false && this.employeenewAppresialDet.AppraisalAmount) &&
           !this.empSalaryDetService.isAppraisalAmountVisibleForUnfix) {
        this.employeenewAppresialDet.AppraisalAmount = null;
      }
      this.employeenewAppresialDet.EmpId = this.employeeDetails[0].EmpId;
      this.employeenewAppresialDet.EmployeeName = this.employeeDetails[0].EmployeeName;
      this.employeenewAppresialDet.DateOfJoining = this.employeeDetails[0].DateOfJoining;
      this.employeenewAppresialDet.DesignationId = this.employeeDetails[0].DesignationId;
      this.employeenewAppresialDet.DepartmentId = this.employeeDetails[0].DepartmentId;
      this.employeenewAppresialDet.AprType = this.employeeDetails[0].AprType;
      this.employeenewAppresialDet.CompanyId = this.employeeDetails[0].CompanyId;
      this.employeenewAppresialDet.Salary = this.employeeDetails[0].Salary;
      this.employeenewAppresialDet.UanNumber = this.employeeDetails[0].UanNumber;
    }
    // if employee aprDetails have a status 0 then execute update requi
    if (this.isForUpdate) {
      this.updateEmployeeAppresialDetailsByAprId();
    } else {
      if (this.employeeDetails[0].Status || this.isMultipleEntry) {
        this.addNewEmployeeAppresialDetails();
      } else {
        this.updateEmployeeAppresialDetails();
      }
    }
  }

  private updateEmployeeAppresialDetailsByAprId(): void {
    if (this.empSalaryDetService.aprIdForUpdtAprDetails) {
      this.empSalaryDetService.updateEmployeeApprDetFirstTime(this.employeenewAppresialDet,
        this.empSalaryDetService.aprIdForUpdtAprDetails).subscribe(
          (data) => {
            this.refAppresialForm.resetForm();
            this.toastr.success('Details updated sucessfully');
            this.empSalaryDetService.isAppraisalAmountVisibleForUnfix = false;
            this.isAprAmountAlwaysVisible = false;
            this.router.navigate(['manage/employee-details']);
          }
        );
    }
  }

  private updateEmployeeAppresialDetails(): void {
    this.empSalaryDetService.updateEmployeeApprDetFirstTime(this.employeenewAppresialDet, this.employeeDetails[0].AprId).subscribe(
      (data) => {
        this.refAppresialForm.resetForm();
        this.toastr.success('Save Sucessfully');
        this.router.navigate(['manage/employee-details']);
      }
    );
  }

  public addNewEmployeeAppresialDetails(): void {
    this.empSalaryDetService.saveAppresialDetails(this.employeenewAppresialDet).subscribe(
      (data) => {
        this.toastr.success('Save Sucessfully');
        if (this.isMultipleEntry) {
          this.refAppresialForm.resetForm();
          this.setEmployeeDetails(this.employeeId);
        } else {
          this.refAppresialForm.resetForm();
          this.router.navigate(['manage/employee-details']);
        }
      }
    );
  }

  public back(): void {
    if (this.empSalaryDetService.isForUpdate) {
      this.router.navigate(['manage/employee-details']);
    } else {
      this.router.navigate(['manage/employee-details']);
    }
  }

  ngOnDestroy() {
    this.empSalaryDetService.empIdForAppresial = null;
    this.empSalaryDetService.isForUpdate = false;
    this.empSalaryDetService.aprIdForUpdtAprDetails = null;
    this.empSalaryDetService.isAppraisalAmountVisibleForUnfix = false;
  }
}

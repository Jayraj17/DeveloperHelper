import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material';
import {MatDialog} from '@angular/material/dialog';
import { EmployeeRegisterService } from '../services/employee-register.service';
import { Appresial } from '../models/appresial.false';
import { EmployeeSalaryDetailsService } from 'src/app/Employee-Salary-Details/service/employee-salary-details.service';
import { Router } from '@angular/router';
import { SharedServiceService } from 'src/app/services/shared-service.service';

@Component({
  selector: 'app-employee-appraisal-details',
  templateUrl: './employee-appraisal-details.component.html',
  styleUrls: ['./employee-appraisal-details.component.css']
})
export class EmployeeAppraisalDetailsComponent implements OnInit {

  private eId: number;
  public employeeAppraisalDetails: Appresial[];
  public isVisible: boolean = true;
  public display: boolean = true;
  public employeeName: string = null;

  constructor(@Inject(MAT_DIALOG_DATA) public data: any, private employeeRegService: EmployeeRegisterService,
              private employeeSalService: EmployeeSalaryDetailsService, private router: Router, public dialog: MatDialog,
              private sharedService: SharedServiceService) { }

  ngOnInit() {
    this.eId = this.data.employeeId;
    this.employeeName = this.data.employeeName;
    this.employeeRegService.getEmployeeAppraisalDetails(this.eId).subscribe(
      (data: Appresial[]) => {
       if (data.length && data.length !== 0 && data.length > 0) {
          this.employeeAppraisalDetails =  this.sharedService.setLastAppraisialEditable(data);
          this.display = true;
        } else {
          this.isVisible = false;
       }
      }
    );
  }

  // a => apprasial
  public editApprasialDetails(aId: number, isActiveSalary: boolean): void {
    this.employeeSalService.isAppraisalAmountVisibleForUnfix = false;
    if (!isActiveSalary || isActiveSalary !== true) {
      this.employeeSalService.aprIdForUpdtAprDetails = aId;
      this.employeeSalService.isAppraisalAmountVisibleForUnfix = false;
    } else {
      this.employeeSalService.aprIdForUpdtAprDetails = aId;
      this.employeeSalService.isAppraisalAmountVisibleForUnfix = true;
    }
    // this.employeeSalService.aprIdForUpdtAprDetails = aId;
    this.dialog.closeAll();
    this.router.navigate(['manage/appraisal']);
  }

}

import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { EmployeeDetailsTableComponent } from './employee-details-table/employee-details-table.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { EmployeeRegisterComponent } from './employee-register/employee-register.component';
import { EmployeeResignationComponent } from './employee-resignation/employee-resignation.component';
import { ViewResignationEmployeeComponent } from './view-resignation-employee/view-resignation-employee.component';
import { EmployeeAppresialComponent } from './employee-appresial/employee-appresial.component';
import { RouterModule, Routes } from '@angular/router';
import { EmployeeAppraisalDetailsComponent } from './employee-appraisal-details/employee-appraisal-details.component';
import { EmpManageComListComponent } from './emp-manage-com-list/emp-manage-com-list.component';


export const routes: Routes = [
   { path: '', component: EmpManageComListComponent },
   { path: 'employee-details', component: EmployeeDetailsTableComponent},
   { path: 'register', component: EmployeeRegisterComponent },
   { path: 'appraisal', component: EmployeeAppresialComponent },
   { path: 'resignation-employee', component: ViewResignationEmployeeComponent },
   { path: 'resignation', component:  EmployeeResignationComponent},
   { path: '**', redirectTo: '', pathMatch: 'full' }
];



@NgModule({
  declarations: [
    EmployeeDetailsTableComponent,
    EmployeeListComponent,
    EmployeeRegisterComponent,
    EmployeeResignationComponent,
    ViewResignationEmployeeComponent,
    EmployeeAppresialComponent,
    EmployeeAppraisalDetailsComponent,
    EmpManageComListComponent
  ],
  imports: [
    SharedModule,
    RouterModule.forChild(routes)
  ],
  entryComponents: [EmployeeAppraisalDetailsComponent, EmployeeListComponent]
})
export class EmployeeRegisterModule { }

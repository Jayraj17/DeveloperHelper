import { Component, OnInit, Inject } from '@angular/core';
import { EmployeeRegister } from 'src/app/Employee-Register-Components/models/employee-register';
import { EmployeeRegisterService } from 'src/app/Employee-Register-Components/services/employee-register.service';
import { MAT_DIALOG_DATA, MatDialog } from '@angular/material';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  constructor(@Inject(MAT_DIALOG_DATA) public data: any, private employeeRegService: EmployeeRegisterService,
              private route: Router, public dialog: MatDialog, private toastr: ToastrService) { }

  employeeId: number = null;
  public employee: EmployeeRegister;
  public viewVisible: boolean = true;

  ngOnInit() {
     this.employee = this.data.employeeDetails;
     this.employeeId = this.employee.EmpId;
  }

  public employeeResignation(): void {
    this.dialog.closeAll();
    this.employeeRegService.employeeIdForResignation = this.employeeId;
    this.route.navigate(['manage/resignation']);
  }

}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-emp-manage-com-list',
  templateUrl: './emp-manage-com-list.component.html',
  styleUrls: ['./emp-manage-com-list.component.css']
})
export class EmpManageComListComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }

  public addUser(): void {
    this.router.navigate(['manage/register']);
  }

  public navigateToManageEmployee(): void {
    this.router.navigate(['manage/employee-details']);
  }

  public navigateToResignEmployee(): void {
    this.router.navigate(['manage/resignation-employee']);
  }

}

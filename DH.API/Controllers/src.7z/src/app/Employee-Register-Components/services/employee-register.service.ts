import { Injectable } from '@angular/core';
import { EmployeeRegister } from '../models/employee-register';
import { Observable } from 'rxjs';
import { Designation } from '../../models/designation.model';
import { BaseServiceService } from 'src/app/services/base-service.service';
import { Resignation } from 'src/app/Employee-Register-Components/models/resignation.model';
import { Appresial } from '../models/appresial.false';

@Injectable({
  providedIn: 'root'
})
export class EmployeeRegisterService {

  public editEmployeeId: number = null;
  public employeeIdForResignation: number = null;
  public isNotificationView: boolean;

  constructor(private baseServiceService: BaseServiceService) { }

  public RegisterEmployee(employee: EmployeeRegister): Observable<EmployeeRegister> {
    return this.baseServiceService.post('EmployeeDetails/InsertEmployee', employee);
  }

  public GetEmployee(): Observable<EmployeeRegister[]> {
    return this.baseServiceService.post('EmployeeDetails/GetEmployee' + '/', { id : 0 });
  }

  public GetEmployeeByDepartment(departmentId: string) {
    return this.baseServiceService.post('EmployeeDetails/GetEmployee' + '/', { id : 0, Search: '', DeptIdStr : departmentId });
  }

  public GetEmployeeById(employeeId: number): Observable<EmployeeRegister> {
    return this.baseServiceService.post('EmployeeDetails/GetEmployee', {id : employeeId});
  }

  public UpdateEmployee(id: number, employeeData: EmployeeRegister): Observable<EmployeeRegister> {
    return this.baseServiceService.put('EmployeeDetails/UpdateEmployee' + '/' + id, employeeData);
  }

  public DeleteEmployee(id: number) {
    return this.baseServiceService.delete('EmployeeDetails/DeleteEmployee/', id);
  }

  public getSalaryCode() {
    return this.baseServiceService.get('SalaryStruct/GetStruct/0');
  }

  public insertEmployeeResignationDetails(resignationData: Resignation) {
    return this.baseServiceService.post('RelievingDetails/InsertEmployee', resignationData);
  }

  public getEmployeeResignationDetails() {
    return this.baseServiceService.get('RelievingDetails/GetEmployee/0');
  }

  public getEmployeeResignationDetailsById(id: number) {
    return this.baseServiceService.get('RelievingDetails/GetEmployee/' + id);
  }

  public updateEmployeeResignationDetails(resignationData: Resignation) {
    return this.baseServiceService.put('RelievingDetails/UpdateEmployee/' + resignationData.EmpId , resignationData);
  }

  public deleteEmployeeResignationDetails(employeeId: number) {
    return this.baseServiceService.delete('RelievingDetails/DeleteEmployee/' , employeeId);
  }

  public getEmployeeAppraisalDetails(id: number): Observable<Appresial[]> {
    return this.baseServiceService.get(`AppraisalDetails/GetAppraisalHistory/${id}`);
  }

  public addEmployeeApprDetFirstTime(employeeAprDetails: Appresial) {
    return this.baseServiceService.post('AppraisalDetails/InsertAppraisal', employeeAprDetails);
  }

}

import { Component, OnInit, OnDestroy } from '@angular/core';
import { EmployeeSalaryDetailsService } from '../../Employee-Salary-Details/service/employee-salary-details.service';
import { ToastrService } from 'ngx-toastr';
import { MatDialogRef } from '@angular/material';
import { EmployeeAprDetailsService } from '../service/employee-apr-details.service';
import { SharedServiceService } from 'src/app/services/shared-service.service';

@Component({
  selector: 'app-export-employee-app-sheet',
  templateUrl: './export-employee-app-sheet.component.html',
  styleUrls: ['./export-employee-app-sheet.component.css']
})
export class ExportEmployeeAppSheetComponent implements OnInit {

  public selectedFile: File = null;

  constructor(private sharedService: SharedServiceService, private toastr: ToastrService,
              private dialogRef: MatDialogRef<ExportEmployeeAppSheetComponent>) { }

  ngOnInit() {
  }

  public onFileSelected(event): void {
    if (event.target.files.length > 0) {
      this.selectedFile = event.target.files[0];
    }
  }

  public onUpload(): void {
    if (this.selectedFile) {
      const fd = new FormData();
      fd.append('file', this.selectedFile);
      this.sharedService.uploadFile(fd, 'Reports/UploadExcel', 2).subscribe(
        (res) => { this.toastr.success('File uploaded sucessfully'); this.dialogRef.close(); },
        (err) => { this.toastr.error(this.sharedService.errMsgForFileUpload); }
      );
    }
  }

}

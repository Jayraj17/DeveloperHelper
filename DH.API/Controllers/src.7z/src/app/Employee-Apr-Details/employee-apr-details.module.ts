import { NgModule, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeAprComListComponent } from './employee-apr-com-list/employee-apr-com-list.component';
import { Routes, RouterModule } from '@angular/router';
import { UpcomAprDetailsComponent } from './upcom-apr-details/upcom-apr-details.component';
import { SharedModule } from '../shared/shared.module';
import { ExportEmployeeAppSheetComponent } from './export-employee-app-sheet/export-employee-app-sheet.component';

export const routes: Routes = [
  { path: '', component: EmployeeAprComListComponent },
  { path: 'Upcoming-Appraisal', component: UpcomAprDetailsComponent }
];

@NgModule({
  declarations: [
    EmployeeAprComListComponent,
    UpcomAprDetailsComponent,
    ExportEmployeeAppSheetComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule.forChild(routes)
  ],
  entryComponents: [ ExportEmployeeAppSheetComponent ]
})
export class EmployeeAprDetailsModule { }

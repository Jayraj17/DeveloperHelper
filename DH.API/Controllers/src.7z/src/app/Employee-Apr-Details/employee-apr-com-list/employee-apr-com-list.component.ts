import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material';
import { ExportEmployeeAppSheetComponent } from '../export-employee-app-sheet/export-employee-app-sheet.component';

@Component({
  selector: 'app-employee-apr-com-list',
  templateUrl: './employee-apr-com-list.component.html',
  styleUrls: ['./employee-apr-com-list.component.css']
})
export class EmployeeAprComListComponent implements OnInit {

  constructor(private route: Router, private dialog: MatDialog) { }

  ngOnInit() {
  }

  public navigateToUPCAprDetails(): void {
    this.route.navigate(['employee-apprasial-details/Upcoming-Appraisal']);
  }

  public uploadAprDetails(): void {
    this.dialog.open(ExportEmployeeAppSheetComponent);
  }

}

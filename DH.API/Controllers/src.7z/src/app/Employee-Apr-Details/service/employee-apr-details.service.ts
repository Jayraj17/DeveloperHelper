import { Injectable } from '@angular/core';
import { BaseServiceService } from 'src/app/services/base-service.service';
import { Observable } from 'rxjs';
import { Appresial } from 'src/app/Employee-Register-Components/models/appresial.false';

@Injectable({
  providedIn: 'root'
})
export class EmployeeAprDetailsService {

  constructor(private baseService: BaseServiceService) { }


  public getUpcAprDetails(month: any, year: number): Observable<Appresial[]> {
    return this.baseService.get('AppraisalDetails/GetAppraisalByMonthAndYear?month=' + month + '&year=' + year);
  }


}

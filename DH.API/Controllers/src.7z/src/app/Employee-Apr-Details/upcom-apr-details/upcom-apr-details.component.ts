import { Component, OnInit, ViewChild } from '@angular/core';
import { EmployeeRegisterService } from 'src/app/Employee-Register-Components/services/employee-register.service';
import { Companycode } from 'src/app/models/companycode';
import { EmployeeSalaryDetailsService } from '../../Employee-Salary-Details/service/employee-salary-details.service';
import { MatTableDataSource, MatSort, MatPaginator } from '@angular/material';
import { Appresial } from 'src/app/Employee-Register-Components/models/appresial.false';
import { ToastrService } from 'ngx-toastr';
import { EmployeeAprDetailsService } from '../service/employee-apr-details.service';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';
import { SharedServiceService } from 'src/app/services/shared-service.service';

@Component({
  selector: 'app-upcom-apr-details',
  templateUrl: './upcom-apr-details.component.html',
  styleUrls: ['./upcom-apr-details.component.css']
})
export class UpcomAprDetailsComponent implements OnInit {

  public selectedCompanyIdForAppresial: number = 0;
  public getYearForSearch: number;
  public companyCodes: Companycode[];
  public monthsForSearch: string[] = [];
  public yearForSearch: number[] = [];
  public currentYear: Date = new Date();
  public getMonthForSearch: any;
  public isVisibleDownload: boolean;
  private employeeAprDetails: Appresial[];
  public isVisibleTable: boolean;
  public isError: boolean = false;
  public selectedMonth: number[] = [];
  dataSource: any = new MatTableDataSource<any>();

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;

  public months: any[] = [];

  public displayedColumns: string[] = ['EmployeeName', 'CompanyName', 'DepartmentName', 'DesignationName', 'Salary', 'AprMonth',
                                       'AprYear', 'AprType'];

  constructor(private employeeRegService: EmployeeRegisterService, private employeeAprService: EmployeeAprDetailsService,
              private toastr: ToastrService, private router: Router, private sharedService: SharedServiceService) { }

  ngOnInit() {
    this.months = this.sharedService.getMonths();
    this.yearForSearch = this.sharedService.getYears(false);
    this.dataSource.paginator = this.paginator;
    this.sharedService.getCompanyCodes().subscribe(
      (data: Companycode[]) => {
        this.companyCodes = data;
      }
    );
  }

  public searchEmpAprDetails(): void {
    if (!this.getYearForSearch || this.selectedMonth.length === 0) {
      if (!this.getYearForSearch) {
        this.toastr.error('Please select year');
      } else {
        this.toastr.error('Please select month');
      }
    } else {
      this.employeeAprService.getUpcAprDetails(this.selectedMonth.toString(), this.getYearForSearch)
        .subscribe(
          (data) => {
            if (data.length === 0) {
              this.isVisibleTable = false;
              this.isVisibleDownload = false;
              this.isError = true;
            } else {
              this.isVisibleDownload = true;
              this.employeeAprDetails = data;
              this.isVisibleTable = true;
              this.isError = false;
              this.setTableDate(this.employeeAprDetails);
            }
          }
        );
    }

  }

  public setTableDate(tableData: Appresial[]): void {
    this.dataSource = new MatTableDataSource<Appresial>(tableData);
  }

  public aprDetailsDownload(): void {
    this.getMonthForSearch = this.selectedMonth.toString();
    window.location.href =
    'http://192.168.1.235:8088/Reports/ExportAppraisalByMonthAndYear?month=' + this.selectedMonth + '&year=' + this.getYearForSearch;
  }

  public navigateToComList(): void {
    this.router.navigate(['employee-apprasial-details']);
  }

}

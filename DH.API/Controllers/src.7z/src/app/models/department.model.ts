export class Department {
  public DeptId?: number;
  public DepartmentName: string;
}

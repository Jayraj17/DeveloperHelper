export class Designation {
  public DesigId?: number;
  public DesignationName: string;
}

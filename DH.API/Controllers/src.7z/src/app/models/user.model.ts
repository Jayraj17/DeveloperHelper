export class User {
    public FirstName: string;
    public LastName: string;
    public Email: string;
    public UserName: string;
    public Password: string;
}

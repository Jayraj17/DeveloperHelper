export class Companycode {
    public ComapnyId?: number;
    public CompanyName: string;
}


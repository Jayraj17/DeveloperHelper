import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommonComponent } from './common/common.component';
import { Routes, RouterModule } from '@angular/router';
import { MaterialModule } from '../material.module';
import { SharedModule } from '../shared/shared.module';

export const route: Routes = [
  { path: '', component: CommonComponent }
];

@NgModule({
  declarations: [CommonComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(route),
    MaterialModule,
    SharedModule
  ]
})
export class ManageOtherModule { }

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-office-expence-com-list',
  templateUrl: './office-expence-com-list.component.html',
  styleUrls: ['./office-expence-com-list.component.css']
})
export class OfficeExpenceComListComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }

  public navigateToAddExpense(): void {
    this.router.navigate(['office-expence/add-new-expense']);
  }

  public navigateToViewExpense(): void {
    this.router.navigate(['office-expence/office-expense-list']);
  }

  public navigateToGenExpense(): void {
    this.router.navigate(['office-expence/invoice']);
  }

}

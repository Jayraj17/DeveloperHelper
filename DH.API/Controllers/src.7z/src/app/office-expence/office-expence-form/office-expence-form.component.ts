import { Component, OnInit, ViewChild } from '@angular/core';
import { OfficeExpenseService } from '../services/office-expense.service';
import { FormControl, NgForm } from '@angular/forms';
import { ExpenceList } from '../models/expence-list.model';
import { OfficeExpense } from '../models/office-expense.model';
import { Companycode } from 'src/app/models/companycode';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { startWith, map } from 'rxjs/operators';
import { ExpenseList } from '../invoice/invoice.component';
import { SharedServiceService } from 'src/app/services/shared-service.service';

@Component({
  selector: 'app-office-expence-form',
  templateUrl: './office-expence-form.component.html',
  styleUrls: ['./office-expence-form.component.css']
})

export class OfficeExpenceFormComponent implements OnInit {

  public expenceList: ExpenceList[] = [];
  public expenseListBySerch: Observable<ExpenseList[]>;
  public paidTypes: Paidtype[];
  public companyCodes: Companycode[];
  public officeExpence: OfficeExpense;
  public myControl = new FormControl();
  public visible: boolean;
  public date: Date = new Date();
  public searchTerm: string;


  @ViewChild('refExpenceForm', { static: true }) public expenceForm: NgForm;

  constructor(private officeExpService: OfficeExpenseService, private toastr: ToastrService, private router: Router,
              private sharedService: SharedServiceService) { }

  ngOnInit() {
    this.nullObject();
    this.officeExpService.getFixExpenceList().subscribe(
      (data: ExpenceList[]) => {
        this.expenceList = data;
      }
    );
    this.officeExpService.getPaidType().subscribe(
      (data) => {
        this.paidTypes = data;
      }
    );
    this.sharedService.getCompanyCodes().subscribe(
      (data) => {
        this.companyCodes = data;
      }
    );
  }

  public setExpence(expenceId: number): void {
    if (expenceId === 30) {
      this.visible = true;
    } else {
      this.visible = false;
    }
    this.officeExpence.ListId = expenceId;
  }

  public saveExpence() {
    if (this.expenceForm.invalid) {
      return;
    } else {
      if (!this.officeExpence.RemindMe && this.officeExpence.ReminderOn) {
        this.officeExpence.ReminderOn = null;
      }
      if (this.officeExpence.ListId !== 30 && !this.officeExpence.Other) {
        this.officeExpence.Other = null;
      }
      if (this.officeExpence.PaidTypeId !== 3 && this.officeExpence.CompanyId !== null) {
        this.officeExpence.CompanyId = null;
      }
      this.officeExpService.saveExpense(this.officeExpence).subscribe(
        (data) => {
          if (this.officeExpence.RemindMe && this.officeExpence.ReminderOn) {
            this.notification();
          } else {
            this.toastr.success('Expense Added Sucessfully..');
            this.expenceForm.resetForm();
            this.nullObject();
            this.myControl.reset();
          }
        }
      );
    }
  }

  private notification(): void {
    this.officeExpService.setNotificationForExpense(this.officeExpence).subscribe(
      (data) => {
        this.toastr.success('Expense Added Sucessfully..');
        this.expenceForm.resetForm();
        this.nullObject();
        this.myControl.reset();
      }
    );
  }

  private nullObject(): void {
    this.officeExpence = {
      ListId: null,
      Amount: null,
      ApplicableDate: null,
      CompanyId: null,
      Description: null,
      CompanyName: null,
      ExpenseName: null,
      PaidTypeId: null,
      PaidTypeName: null,
      RemindMe: null,
      ReminderOn: null,
      Other: null
    };
  }
  public back(): void {
    this.router.navigate(['office-expence']);
  }
}

export class Paidtype {
  PaidTypeId?: number;
  PaidTypeName: string;
}

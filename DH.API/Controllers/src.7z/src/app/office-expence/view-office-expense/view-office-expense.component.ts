import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { OfficeExpenseService } from '../services/office-expense.service';
import { OfficeExpense } from '../models/office-expense.model';
import { MatSort, MatPaginator, MatTableDataSource } from '@angular/material';
import { Router } from '@angular/router';
import { Companycode } from 'src/app/models/companycode';
import { ToastrService } from 'ngx-toastr';
import { ExportEmployeeService } from 'src/app/services/export-employee.service';
import { SharedServiceService } from 'src/app/services/shared-service.service';

@Component({
  selector: 'app-view-office-expense',
  templateUrl: './view-office-expense.component.html',
  styleUrls: ['./view-office-expense.component.css']
})
export class ViewOfficeExpenseComponent implements OnInit {

  public id = 0;
  public expenceList: OfficeExpense[];
  public copyExpenseList: OfficeExpense[];
  public dataSource: any;
  public searchByText = '';
  public departments: Companycode[];
  public departmentId = 0;
  public isLoading = true;
  public total: number;
  public currentYear: Date = new Date();
  public yearForSearch: any[] = [];
  public monthsForSearch: string[] = [];
  private months: any[] = [];
  public getYearForSearch: number;
  public getMonthForSearch: number;

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild('content', { static: true }) content: ElementRef;

  displayedColumns: string[] = ['Company_Name', 'PaidTypeName', 'Expense_name', 'Description', 'Applicable_Date', 'Amount', 'Delete'];

  constructor(private officeExpService: OfficeExpenseService, private router: Router, private toastr: ToastrService,
              private exportDataService: ExportEmployeeService, private sharedService: SharedServiceService) { }

  ngOnInit() {
    this.months = this.sharedService.getMonths();
    this.yearForSearch = this.sharedService.getYears(true);
    this.officeExpService.getExpenseList(this.id).subscribe(
      (data: OfficeExpense[]) => {
        this.expenceList = data;
        this.setMaterialTable(this.expenceList);
        this.getTotalAmountOfExpense(this.expenceList);
        this.isLoading = false;
      }
    );
    this.sharedService.getCompanyCodes().subscribe(
      (data: Companycode[]) => {
        this.departments = data;
      }
    );
    if (this.expenceList) {
      this.dataSource.sort = this.sort;
    }
  }

  // Code for Angular material table with search by text,department and filter

  private setMaterialTable(tableData: OfficeExpense[]) {
    this.getTotalAmountOfExpense(tableData);
    this.copyExpenseList = tableData;
    this.dataSource = new MatTableDataSource<OfficeExpense>(tableData);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  public applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  public resetSearchBox(): void {
    this.searchByText = '';
    this.setMaterialTable(this.copyExpenseList);
  }

  // End angular material table

  // Code for search by month and date

  public setMonthOnSelectedYear(getYearForSearch): void {
    this.getMonthForSearch = null;
    if (getYearForSearch === this.currentYear.getFullYear()) {
      this.monthsForSearch = [];
      for (let i = 0; i <= this.currentYear.getMonth(); i++) {
        this.monthsForSearch.push(this.months[i]);
      }
    } else {
      this.monthsForSearch = this.months;
    }
  }

  public searchByMonthAndYear(): void {
    if (this.getYearForSearch && this.getMonthForSearch) {
      this.officeExpService.getTableDataByMonthAndYear(this.getMonthForSearch, this.getYearForSearch).subscribe(
        (data: OfficeExpense[]) => {
          this.expenceList = data;
          this.setMaterialTable(this.expenceList);
          this.getTotalAmountOfExpense(this.expenceList);
          this.isLoading = false;
        }
      );
    } else {
      this.toastr.error('Please select month and year');
    }
  }

  public searchByDepartment() {
    this.officeExpService.getExpenseList(this.departmentId).subscribe(
      (data: OfficeExpense[]) => {
        this.setMaterialTable(data);
        this.expenceList = data;
      }
    );
  }


  // delete the expense

  public deleteExpense(id: number): void {
    if (confirm('ayr you sure you want to delete expense')) {
      this.officeExpService.deleteExpense(id).subscribe(
        (data) => {
          this.toastr.success('Expense Deleted Successfully');
          this.searchByDepartment();
        }
      );
    }
  }

  // return the sum total expense

  public getTotalAmountOfExpense(officeExpense: OfficeExpense[]) {
    this.total = officeExpense.map(t => t.Amount).reduce((amount, value) => amount + value, 0);
  }

  // download office-expense data in excle sheet

  public exportOfficeExpense(): void {
    this.removeUnimportedColumn(this.expenceList);
    this.exportDataService.exportAsExcelFile(this.expenceList, 'Office-Expense');
  }

  // Remove the object array key when export the data in excle sheet

  private removeUnimportedColumn(offExpData: OfficeExpense[]): void {
    offExpData.forEach(
      (data, index) => {
          delete offExpData[index].ExpenseId,
          delete offExpData[index].ApplicableDate,
          delete offExpData[index].CompanyId,
          delete offExpData[index].PaidTypeId,
          delete offExpData[index].ListId,
          delete offExpData[index].RefNumber,
          delete offExpData[index].ReminderOn,
          delete offExpData[index].CreatedOn,
          delete offExpData[index].CreatedBy,
          delete offExpData[index].UpdatedBy,
          delete offExpData[index].UpdatedOn,
          delete offExpData[index].IsActive,
          delete offExpData[index].IsDelete,
          delete offExpData[index].IsGenerated;
      });
  }

  public back(): void {
    this.router.navigate(['office-expence']);
  }

}

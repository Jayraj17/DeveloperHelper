import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import * as jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { OfficeExpenseService } from '../services/office-expense.service';
import { Companycode } from 'src/app/models/companycode';
import { ToastrService } from 'ngx-toastr';
import { SharedServiceService } from 'src/app/services/shared-service.service';


@Component({
  selector: 'app-invoice',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.css']
})
export class InvoiceComponent implements OnInit {

  public totalSum;
  private heightLeft: any;
  private position: any;
  private pdf: any;
  public data: any;
  public invoiceNumber: any;
  public selectedCompanyIdForGenerateInvoice: any = null;
  private imgWidth: number;
  private pageHeight: number;
  private imgHeight: number;
  public totalExpenseSum: number = 0;
  // tslint:disable-next-line: no-inferrable-type
  public sumOfMonthlyCashExpense: number;
  public expenseLists: ExpenseList[];
  public companyCodes: Companycode[];
  public invoiceCompanyDetails: InvoiceCompanyDetails;
  public cashExpenseList: ExpenseList[];
  public currentYear: Date = new Date();
  public yearForSearch: any[] = [];
  public monthsForSearch: string[] = [];
  // public months: any[] = [];
  private months: any[] = [];
  public getYearForSearch: number;
  public getMonthForSearch: number;
  public companyLogoName: string;
  public isVisibleInvoise: boolean;

  // for lock invoice
  public isCheckForLockInvoice: boolean = false;
  public isCheckBoxDisable: boolean = false;
  public isInvoiceAlreadyGenerated: boolean = false;
  public dateForLockInvoice: Date = null;


  @ViewChild('content', { static: true }) content: ElementRef;


  constructor(private officeExpService: OfficeExpenseService, private toastr: ToastrService,
              private sharedService: SharedServiceService) { }

  ngOnInit() {
    this.months = this.sharedService.getMonths();
    this.yearForSearch = this.sharedService.getYears(true);
    this.sharedService.getCompanyCodes().subscribe(
      (data: Companycode[]) => {
        this.companyCodes = data;
      }
    );
  }

  public getCompanyInvoiceDetails(conpanyId: number): void {
    this.officeExpService.getInvoiceCompanyDetails(conpanyId).subscribe(
      (data: InvoiceCompanyDetails) => {
        this.invoiceCompanyDetails = data;
      }
    );
    this.officeExpService.getFinalInvoiseExpense(conpanyId).subscribe(
      (data: ExpenseList[]) => {
        this.expenseLists = data;
        this.getSumOfTotalEXpense(this.expenseLists);
        this.monthlyCashExpenseSum(this.expenseLists);
      }
    );
  }

  private monthlyCashExpenseSum(expenseList: ExpenseList[]): void {
    this.sumOfMonthlyCashExpense = 0;
    this.cashExpenseList = expenseList.filter(expenseDetails => expenseDetails.PaidTypeId === 1);
    // tslint:disable-next-line: prefer-for-of
    for (let i = 0; i < this.cashExpenseList.length; i++) {
      this.sumOfMonthlyCashExpense += this.cashExpenseList[i].Amount;
    }
    this.removeCashExpense(expenseList);
  }

  private removeCashExpense(expenseList: ExpenseList[]): void {
    for (let i = 0; i < expenseList.length; i++) {
      if (expenseList[i].PaidTypeId === 1) {
        expenseList.splice(i, 1);
        i--;
      }
    }
  }

  private getSumOfTotalEXpense(expenseList: ExpenseList[]) {
    this.totalExpenseSum = 0;
    // tslint:disable-next-line: prefer-for-of
    for (let i = 0; i < expenseList.length; i++) {
      this.totalExpenseSum += expenseList[i].Amount;
    }
    this.totalSum = this.totalExpenseSum;

  }

  public generatePDF(): void {
    // this.lockInvoiseDetail();
    this.data = document.getElementById('content');
    html2canvas(this.data).then(canvas => {
      this.imgWidth = 208;
      //  this.pageHeight = 295;
      this.imgHeight = canvas.height * this.imgWidth / canvas.width;
      this.heightLeft = this.imgHeight;

      const contentDataURL = canvas.toDataURL('image/png');
      this.pdf = new jsPDF('p', 'mm', 'a4'); // A4 size page of PDF
      this.position = 3;
      this.pdf.addImage(contentDataURL, 'PNG', 1, this.position, this.imgWidth, this.imgHeight);
      this.pdf.save('Invoice.pdf'); // Generated PDF
    });
  }

  public excleDownload(): void {

    if (this.isInvoiceAlreadyGenerated === false && !this.isInvoiceAlreadyGenerated) {
      if (this.isCheckForLockInvoice === true && this.isCheckBoxDisable === false && this.dateForLockInvoice !== null) {
        this.lockInvoiseDetail();
      }
   }

    if (this.isCheckForLockInvoice === true && this.isCheckBoxDisable === false && this.dateForLockInvoice === null) {
      this.toastr.error('Please select valid details');
      return;
    } else if (this.isCheckForLockInvoice === false && this.dateForLockInvoice !== null) {
      this.dateForLockInvoice = null;
    } else if (this.isCheckForLockInvoice === true && this.isCheckBoxDisable === true && this.dateForLockInvoice === null) {
      window.location.href = `http://192.168.1.235:8088/Report/InvoiceExportToExcel/` +
      this.selectedCompanyIdForGenerateInvoice + '/' + this.getMonthForSearch + '/' +
      this.getYearForSearch;
    } else {
      window.location.href = `http://192.168.1.235:8088/Report/InvoiceExportToExcel/` +
      this.selectedCompanyIdForGenerateInvoice + '/' + this.getMonthForSearch + '/' +
      this.getYearForSearch;
    }

  }

  private lockInvoiseDetail() {
    this.officeExpService.lockInvoiseDetails(this.getMonthForSearch, this.getYearForSearch, this.dateForLockInvoice).subscribe(
      (data) => { }, (error) => {
        this.toastr.error('Something Wrong...');
      }
    );
  }

  private getInvoiseNumber(companyName: string, month: number, year: number) {
    this.invoiceNumber = companyName + '-' + month + '/' + year;
  }


  public getInvoiceDate(): Date {
    return new Date();
  }

  // Code for search by month and date

  public setMonthOnSelectedYear(getYearForSearch): void {
    this.getMonthForSearch = null;
    if (getYearForSearch === this.currentYear.getFullYear()) {
      this.monthsForSearch = [];
      for (let i = 0; i <= this.currentYear.getMonth(); i++) {
        this.monthsForSearch.push(this.months[i]);
      }
    } else {
      this.monthsForSearch = this.months;
    }
  }

  private setCompanyLogo(companyId: number): void {
    switch (companyId) {
      case 1: this.companyLogoName = 'assets/seachx-logo.png';
              break;
      case 2: this.companyLogoName = 'assets/logo-black.png';
              break;
      case 3: this.companyLogoName = 'assets/kidsXap.png';
              break;
      case 4: this.companyLogoName = 'assets/search.png';
              break;
      case 5: this.companyLogoName = 'assets/webzlabz-logo.png';
              break;
      default: break;
    }
  }

  public searchByMonthAndYear(): void {
    if (this.getYearForSearch && this.getMonthForSearch && this.selectedCompanyIdForGenerateInvoice) {
      this.setCompanyLogo(this.selectedCompanyIdForGenerateInvoice);
      this.officeExpService.getInvoiceCompanyDetails(this.selectedCompanyIdForGenerateInvoice).subscribe(
        (data: InvoiceCompanyDetails) => {
          this.invoiceCompanyDetails = data;
          // this.getInvoiceNumber(this.invoiceCompanyDetails[0].CompanyName);
          this.getInvoiseNumber(this.invoiceCompanyDetails[0].CompanyName, this.getMonthForSearch, this.getYearForSearch);
        }
      );
      this.officeExpService.getFinalInvoiseByMonthAndYear(this.selectedCompanyIdForGenerateInvoice, this.getMonthForSearch,
        this.getYearForSearch).subscribe(
          (data: ExpenseList[]) => {
            if (data.length > 0) {
              this.isCheckForLockInvoice = data[0].IsGenerated;
              if (data[0].IsGenerated === true) {
                 this.isCheckBoxDisable = true;
                 this.isInvoiceAlreadyGenerated = true;
              }
              this.expenseLists = data;
              this.getSumOfTotalEXpense(this.expenseLists);
              this.monthlyCashExpenseSum(this.expenseLists);
              this.isVisibleInvoise = true;
            } else {
              this.isVisibleInvoise = false;
            }
          }
        );
    } else {
      this.toastr.error('Please Select Details');
    }
  }

}

export class InvoiceCompanyDetails {
  comapnyId?: number;
  CompanyName: string;
  createdOn?: Date;
  createdBy?: Date;
  client: string;
  contactNo: number;
  email: string;
  // tslint:disable-next-line: eofline
}


export class ExpenseList {
  Amount: number;
  Description: string;
  PaidTypeId?: number;
  IsGenerated?: boolean;
  GeneratedOn?: Date;
  // tslint:disable-next-line: eofline
}
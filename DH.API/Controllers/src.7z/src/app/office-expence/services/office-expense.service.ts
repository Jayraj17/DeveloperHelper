import { Injectable } from '@angular/core';
import { BaseServiceService } from 'src/app/services/base-service.service';
import { OfficeExpense } from '../models/office-expense.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class OfficeExpenseService {

  private dateForUrl: string;

  constructor(private baseService: BaseServiceService, private http: HttpClient) { }

  public getFixExpenceList() {
    return this.baseService.get('ExpenseDetails/GetExpenseList');
  }

  public getPaidType() {
    return this.baseService.get('ExpenseDetails/GetPaidType');
  }

  public saveExpense(officeExpenceData: OfficeExpense) {
    return this.baseService.post('ExpenseDetails/InsertExpense', officeExpenceData);
  }

  public getExpenseList(id: number) {
    return this.baseService.get('ExpenseDetails/GetExpense/' + id);
  }

  public deleteExpense(id: number) {
    return this.baseService.delete('ExpenseDetails/DeleteExpense/' , id);
  }

  public getInvoiceCompanyDetails(companyId: number) {
    return this.baseService.get('Invoice/GetDetails/' + companyId);
  }

  public getFinalInvoiseExpense(companyId: number) {
    return this.baseService.get('Invoice/GetBodyDetails/' + companyId);
  }

  public getFinalInvoiseByMonthAndYear(compantId: number, month: number, year: number) {
    return this.baseService.get('Invoice/GetBodyDetails/' + compantId + '/' + month + '/' + year);
  }

  public getTableDataByMonthAndYear(month: number, year: number) {
    return this.baseService.get('ExpenseDetails/GetExpenseByMonthAndYear/' + month + '/' + year);
  }

  public lockInvoiseDetails(month: number, year: number, invoiceDate: Date) {
    this.dateForUrl = this.setDateForUrl(invoiceDate);
    return this.baseService.put('ExpenseDetails/LockInvoice/' + month + '/' + year + '/' + this.dateForUrl);
  }

  public setNotificationForExpense(officeExpenseDetail: OfficeExpense) {
    return this.baseService.post('Reminder/SetReminder', officeExpenseDetail);
  }

  private setDateForUrl(date: Date): string {
    return date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDay();
  }
}

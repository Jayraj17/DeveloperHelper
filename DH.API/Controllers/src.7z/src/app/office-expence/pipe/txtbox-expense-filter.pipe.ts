import { Pipe, PipeTransform } from '@angular/core';
import { OfficeExpense } from '../models/office-expense.model';

@Pipe({
  name: 'Expensefilter'
})
export class TxtboxExpenseFilterPipe implements PipeTransform {

  transform(officeExpense: OfficeExpense[], searchTerm: string): OfficeExpense[] {
    if (!officeExpense || !searchTerm) {
      return officeExpense;
    }
    return officeExpense.filter(officeexpense =>
        officeexpense.ExpenseName.toLocaleLowerCase().indexOf(searchTerm.toLocaleLowerCase()) !== -1);

  }

}

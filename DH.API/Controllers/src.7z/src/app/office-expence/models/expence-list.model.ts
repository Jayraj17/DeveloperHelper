export class ExpenceList {
    public ListId?: number;
    public ExpenseName: string;
}

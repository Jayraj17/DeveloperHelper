export class OfficeExpense {
    public ExpenseId?: number;
    public CompanyId: number;
    public PaidTypeId: number;
    public Amount: number;
    public ListId: number;
    public CompanyName: string;
    public PaidTypeName: string;
    public ExpenseName: string;
    public Description: string;
    public RefNumber?: number;
    public ApplicableDate: Date;
    public Other: string;
    public RemindMe: boolean;
    public ReminderOn: Date;
    public CreatedOn?: Date;
    public CreatedBy?: Date;
    public UpdatedOn?: Date;
    public UpdatedBy?: Date;
    public IsActive?: Date;
    public IsDelete?: Date;
    public IsGenerated?: boolean;
}

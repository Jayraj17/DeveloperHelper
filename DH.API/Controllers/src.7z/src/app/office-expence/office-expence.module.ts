import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OfficeExpenceFormComponent } from './office-expence-form/office-expence-form.component';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { ViewOfficeExpenseComponent } from './view-office-expense/view-office-expense.component';
import { InvoiceComponent } from './invoice/invoice.component';
import { OfficeExpenceComListComponent } from './office-expence-com-list/office-expence-com-list.component';
import { TxtboxExpenseFilterPipe } from './pipe/txtbox-expense-filter.pipe';

export const route: Routes = [
  { path : '', component:  OfficeExpenceComListComponent},
  { path: 'office-expense-list', component: ViewOfficeExpenseComponent },
  { path : 'add-new-expense', component: OfficeExpenceFormComponent },
  { path : 'invoice', component: InvoiceComponent }
];

@NgModule({
  declarations:
  [
    OfficeExpenceFormComponent,
    ViewOfficeExpenseComponent,
    InvoiceComponent,
    OfficeExpenceComListComponent,
    TxtboxExpenseFilterPipe
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(route),
    SharedModule
  ]
})
export class OfficeExpenceModule { }

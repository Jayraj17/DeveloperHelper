import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ChangePasswordComponent } from './signup-login/change-password/change-password.component';
import { LoginComponent } from './signup-login/login/login.component';
import { SignupComponent } from './signup-login/signup/signup.component';

// Authentication Guard
import { AuthGuard } from './services/auth/auth.guard';
import { LoginAuthGuard } from './services/auth/login-auth.guard';


const routes: Routes = [
  { path: '', redirectTo: '/Login', pathMatch: 'full' },

  { path: 'Login', component: LoginComponent, canActivate: [LoginAuthGuard] },

  { path: 'dashboard', loadChildren: () => import('./dashboard/dashboard.module').then(m => m.DashboardModule), canActivate: [AuthGuard] },

  { path: 'manage', loadChildren: () => import('./Employee-Register-Components/employee-register.module').
    then(m => m.EmployeeRegisterModule), canActivate: [AuthGuard] },

  {
    path: 'employee-salary-details',
    loadChildren: () => import('./Employee-Salary-Details/employee-salary.module').then(m => m.EmployeeSalaryModule),
    canActivate: [AuthGuard]
  },

  {
    path: 'employee-apprasial-details',
    loadChildren: () => import('./Employee-Apr-Details/employee-apr-details.module'). then(m => m.EmployeeAprDetailsModule),
    canActivate: [AuthGuard]
  },

  {
    path: 'office-expence', loadChildren: () => import('./office-expence/office-expence.module').then(m => m.OfficeExpenceModule),
    canActivate: [AuthGuard]
  },

  { path: 'changePassword', component: ChangePasswordComponent, canActivate: [AuthGuard] },

  { path: 'signup', component: SignupComponent, canActivate: [AuthGuard] },

  {
    path: 'other', loadChildren: () => import('./manage-other/manage-other.module').then(m => m.ManageOtherModule),
    canActivate: [AuthGuard]
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
